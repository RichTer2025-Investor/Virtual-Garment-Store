import React, { useState, useEffect } from 'react';
import { TiendaProvider } from './contexts/TiendaContext';
import { Navegacion } from './components/Navegacion';
import { PaginaInicio } from './components/PaginaInicio';
import { CatalogoProductos } from './components/CatalogoProductos';
import { DetalleProducto } from './components/DetalleProducto';
import { CarritoCompras } from './components/CarritoCompras';
import { Checkout } from './components/Checkout';
import { Login } from './components/Login';
import { PanelAdmin } from './components/PanelAdmin';
import { PaginaOfertas } from './components/PaginaOfertas';
import { Footer } from './components/Footer';
import './App.css';

function App() {
  const [paginaActual, setPaginaActual] = useState('inicio');
  const [productoSeleccionado, setProductoSeleccionado] = useState<number | null>(null);

  // Scroll to top cuando cambia de página
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [paginaActual]);

  const renderizarPagina = () => {
    switch (paginaActual) {
      case 'inicio':
        return (
          <PaginaInicio 
            setPaginaActual={setPaginaActual}
            setProductoSeleccionado={setProductoSeleccionado}
          />
        );
      
      case 'catalogo':
        return (
          <CatalogoProductos 
            setProductoSeleccionado={setProductoSeleccionado}
            setPaginaActual={setPaginaActual}
          />
        );
      
      case 'producto':
        return productoSeleccionado ? (
          <DetalleProducto 
            productoId={productoSeleccionado}
            setPaginaActual={setPaginaActual}
            setProductoSeleccionado={setProductoSeleccionado}
          />
        ) : (
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Producto no encontrado
              </h2>
              <button
                onClick={() => setPaginaActual('catalogo')}
                className="bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition-colors"
              >
                Volver al catálogo
              </button>
            </div>
          </div>
        );
      
      case 'carrito':
        return <CarritoCompras setPaginaActual={setPaginaActual} />;
      
      case 'checkout':
        return <Checkout setPaginaActual={setPaginaActual} />;
      
      case 'login':
        return <Login setPaginaActual={setPaginaActual} />;
      
      case 'admin':
        return <PanelAdmin setPaginaActual={setPaginaActual} />;
      
      case 'ofertas':
        return (
          <PaginaOfertas 
            setProductoSeleccionado={setProductoSeleccionado}
            setPaginaActual={setPaginaActual}
          />
        );
      
      default:
        return (
          <PaginaInicio 
            setPaginaActual={setPaginaActual}
            setProductoSeleccionado={setProductoSeleccionado}
          />
        );
    }
  };

  return (
    <TiendaProvider>
      <div className="min-h-screen bg-gray-50">
        {/* Navegación principal */}
        <Navegacion 
          paginaActual={paginaActual}
          setPaginaActual={setPaginaActual}
        />
        
        {/* Contenido principal */}
        <main className="min-h-screen">
          {renderizarPagina()}
        </main>
        
        {/* Footer */}
        <Footer setPaginaActual={setPaginaActual} />
      </div>
    </TiendaProvider>
  );
}

export default App;
