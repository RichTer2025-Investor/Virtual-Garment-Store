import React from 'react';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Gift } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface CarritoComprasProps {
  setPaginaActual: (pagina: string) => void;
}

export const CarritoCompras: React.FC<CarritoComprasProps> = ({ setPaginaActual }) => {
  const { estado, dispatch } = useTienda();

  const calcularSubtotal = () => {
    return estado.carrito.reduce((total, item) => {
      const precio = item.enOferta 
        ? item.precio * (1 - item.descuento / 100)
        : item.precio;
      return total + (precio * item.cantidad);
    }, 0);
  };

  const calcularEnvio = () => {
    const subtotal = calcularSubtotal();
    const envioGratis = estado.configuracion?.configuracion.envioGratis || 50;
    return subtotal >= envioGratis ? 0 : estado.configuracion?.configuracion.costoEnvio || 5.99;
  };

  const calcularTotal = () => {
    return calcularSubtotal() + calcularEnvio();
  };

  const manejarActualizarCantidad = (index: number, nuevaCantidad: number) => {
    if (nuevaCantidad <= 0) {
      dispatch({ type: 'ELIMINAR_DEL_CARRITO', payload: index });
    } else {
      dispatch({ 
        type: 'ACTUALIZAR_CANTIDAD_CARRITO', 
        payload: { id: index, cantidad: nuevaCantidad } 
      });
    }
  };

  const manejarEliminarItem = (index: number) => {
    dispatch({ type: 'ELIMINAR_DEL_CARRITO', payload: index });
  };

  const manejarProcederAlPago = () => {
    if (estado.carrito.length === 0) {
      alert('Tu carrito está vacío');
      return;
    }
    setPaginaActual('checkout');
  };

  if (estado.carrito.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="text-gray-400 mb-6">
              <ShoppingBag className="h-20 w-20 mx-auto" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Tu carrito está vacío
            </h2>
            <p className="text-gray-600 mb-8">
              Parece que aún no has agregado ningún producto a tu carrito. 
              ¡Explora nuestro catálogo y encuentra algo que te guste!
            </p>
            <button
              onClick={() => setPaginaActual('catalogo')}
              className="w-full bg-primary-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center"
            >
              <ShoppingBag className="h-5 w-5 mr-2" />
              Ir al Catálogo
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Carrito de Compras</h1>
          <p className="text-gray-600">
            {estado.carrito.length} {estado.carrito.length === 1 ? 'producto' : 'productos'} en tu carrito
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Lista de productos */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Productos</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {estado.carrito.map((item, index) => {
                  const precioFinal = item.enOferta 
                    ? item.precio * (1 - item.descuento / 100)
                    : item.precio;

                  return (
                    <div key={index} className="p-6">
                      <div className="flex items-start space-x-4">
                        {/* Imagen del producto */}
                        <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <ShoppingBag className="h-8 w-8 text-primary-600" />
                        </div>

                        {/* Información del producto */}
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {item.nombre}
                          </h3>
                          <p className="text-gray-600 text-sm mb-2">
                            {item.descripcion}
                          </p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span>Talla: {item.tallaSeleccionada}</span>
                            <span>Color: {item.colorSeleccionado}</span>
                          </div>
                          
                          {item.enOferta && (
                            <div className="mt-2">
                              <span className="bg-secondary-100 text-secondary-800 px-2 py-1 rounded-full text-xs font-bold">
                                -{item.descuento}% OFF
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Precio y controles */}
                        <div className="text-right">
                          <div className="mb-3">
                            {item.enOferta ? (
                              <div>
                                <span className="text-lg font-bold text-secondary-600">
                                  €{precioFinal.toFixed(2)}
                                </span>
                                <div className="text-sm text-gray-500 line-through">
                                  €{item.precio.toFixed(2)}
                                </div>
                              </div>
                            ) : (
                              <span className="text-lg font-bold text-gray-900">
                                €{item.precio.toFixed(2)}
                              </span>
                            )}
                          </div>

                          {/* Controles de cantidad */}
                          <div className="flex items-center space-x-2 mb-3">
                            <button
                              onClick={() => manejarActualizarCantidad(index, item.cantidad - 1)}
                              className="p-1 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
                            >
                              <Minus className="h-4 w-4" />
                            </button>
                            <span className="w-8 text-center font-semibold">
                              {item.cantidad}
                            </span>
                            <button
                              onClick={() => manejarActualizarCantidad(index, item.cantidad + 1)}
                              className="p-1 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
                              disabled={item.cantidad >= item.stock}
                            >
                              <Plus className="h-4 w-4" />
                            </button>
                          </div>

                          {/* Subtotal del item */}
                          <div className="text-lg font-bold text-gray-900 mb-2">
                            €{(precioFinal * item.cantidad).toFixed(2)}
                          </div>

                          {/* Botón eliminar */}
                          <button
                            onClick={() => manejarEliminarItem(index)}
                            className="text-red-600 hover:text-red-700 transition-colors flex items-center justify-center"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Eliminar
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Botón continuar comprando */}
              <div className="px-6 py-4 border-t border-gray-200">
                <button
                  onClick={() => setPaginaActual('catalogo')}
                  className="text-primary-600 hover:text-primary-700 font-medium transition-colors"
                >
                  ← Continuar comprando
                </button>
              </div>
            </div>
          </div>

          {/* Resumen de la compra */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Resumen del Pedido</h2>
              
              <div className="space-y-4">
                {/* Subtotal */}
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-semibold">€{calcularSubtotal().toFixed(2)}</span>
                </div>

                {/* Envío */}
                <div className="flex justify-between">
                  <span className="text-gray-600">Envío</span>
                  {calcularEnvio() === 0 ? (
                    <span className="font-semibold text-green-600">Gratis</span>
                  ) : (
                    <span className="font-semibold">€{calcularEnvio().toFixed(2)}</span>
                  )}
                </div>

                {/* Información de envío gratis */}
                {calcularEnvio() > 0 && (
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <Gift className="h-4 w-4 inline mr-1" />
                      Agrega €{(estado.configuracion?.configuracion.envioGratis! - calcularSubtotal()).toFixed(2)} más para envío gratis
                    </p>
                  </div>
                )}

                <hr className="border-gray-200" />

                {/* Total */}
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span>€{calcularTotal().toFixed(2)}</span>
                </div>

                {/* Botón proceder al pago */}
                <button
                  onClick={manejarProcederAlPago}
                  className="w-full bg-primary-600 text-white py-4 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center mt-6"
                >
                  Proceder al Pago
                  <ArrowRight className="h-5 w-5 ml-2" />
                </button>

                {/* Códigos de descuento */}
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h3 className="font-medium text-gray-900 mb-3">Código de Descuento</h3>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      placeholder="Ingresa tu código"
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                    <button className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                      Aplicar
                    </button>
                  </div>
                </div>

                {/* Métodos de pago aceptados */}
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h3 className="font-medium text-gray-900 mb-3">Métodos de Pago</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-gray-100 p-2 rounded text-center text-xs">
                      💳 Tarjeta
                    </div>
                    <div className="bg-gray-100 p-2 rounded text-center text-xs">
                      🟡 PayPal
                    </div>
                    <div className="bg-gray-100 p-2 rounded text-center text-xs">
                      📱 QR
                    </div>
                  </div>
                </div>

                {/* Garantías */}
                <div className="mt-6 pt-6 border-t border-gray-200 space-y-2 text-sm text-gray-600">
                  <div className="flex items-center">
                    <span className="mr-2">🔒</span>
                    Compra 100% segura
                  </div>
                  <div className="flex items-center">
                    <span className="mr-2">📦</span>
                    Envío rápido y seguro
                  </div>
                  <div className="flex items-center">
                    <span className="mr-2">↩️</span>
                    Devoluciones gratuitas 30 días
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Productos recomendados */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">También te puede interesar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {estado.productos.slice(0, 4).map((producto) => (
              <div key={producto.id} className="bg-white rounded-lg shadow-md p-4">
                <div className="aspect-square bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg mb-4 flex items-center justify-center">
                  <ShoppingBag className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{producto.nombre}</h3>
                <p className="text-primary-600 font-bold mb-3">€{producto.precio.toFixed(2)}</p>
                <button
                  onClick={() => {
                    setPaginaActual('producto');
                    // Aquí iría la lógica para seleccionar el producto
                  }}
                  className="w-full bg-primary-600 text-white py-2 rounded-lg hover:bg-primary-700 transition-colors"
                >
                  Ver Producto
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
