import React, { useMemo, useState } from 'react';
import { Filter, Grid, List, SlidersHorizontal, X } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';
import { TarjetaProducto } from './TarjetaProducto';

interface CatalogoProductosProps {
  setProductoSeleccionado: (id: number) => void;
  setPaginaActual: (pagina: string) => void;
}

export const CatalogoProductos: React.FC<CatalogoProductosProps> = ({ 
  setProductoSeleccionado, 
  setPaginaActual 
}) => {
  const { estado, dispatch } = useTienda();
  const [mostrarFiltros, setMostrarFiltros] = useState(false);
  const [vistaGrid, setVistaGrid] = useState(true);
  const [ordenamiento, setOrdenamiento] = useState('relevancia');

  // Filtrar productos
  const productosFiltrados = useMemo(() => {
    let productos = [...estado.productos];

    // Filtro por categoría
    if (estado.filtros.categoria) {
      productos = productos.filter(p => p.categoria === estado.filtros.categoria);
    }

    // Filtro por subcategoría
    if (estado.filtros.subcategoria) {
      productos = productos.filter(p => p.subcategoria === estado.filtros.subcategoria);
    }

    // Filtro por búsqueda
    if (estado.filtros.busqueda) {
      const busqueda = estado.filtros.busqueda.toLowerCase();
      productos = productos.filter(p => 
        p.nombre.toLowerCase().includes(busqueda) ||
        p.descripcion.toLowerCase().includes(busqueda) ||
        p.categoria.toLowerCase().includes(busqueda) ||
        p.subcategoria.toLowerCase().includes(busqueda)
      );
    }

    // Filtro por precio
    productos = productos.filter(p => {
      const precio = p.enOferta ? p.precio * (1 - p.descuento / 100) : p.precio;
      return precio >= estado.filtros.precioMin && precio <= estado.filtros.precioMax;
    });

    // Filtro por talla
    if (estado.filtros.talla) {
      productos = productos.filter(p => p.tallas.includes(estado.filtros.talla));
    }

    // Filtro por color
    if (estado.filtros.color) {
      productos = productos.filter(p => 
        p.colores.some(color => color.toLowerCase().includes(estado.filtros.color.toLowerCase()))
      );
    }

    // Ordenamiento
    switch (ordenamiento) {
      case 'precio-asc':
        productos.sort((a, b) => {
          const precioA = a.enOferta ? a.precio * (1 - a.descuento / 100) : a.precio;
          const precioB = b.enOferta ? b.precio * (1 - b.descuento / 100) : b.precio;
          return precioA - precioB;
        });
        break;
      case 'precio-desc':
        productos.sort((a, b) => {
          const precioA = a.enOferta ? a.precio * (1 - a.descuento / 100) : a.precio;
          const precioB = b.enOferta ? b.precio * (1 - b.descuento / 100) : b.precio;
          return precioB - precioA;
        });
        break;
      case 'nombre':
        productos.sort((a, b) => a.nombre.localeCompare(b.nombre));
        break;
      case 'rating':
        productos.sort((a, b) => b.rating - a.rating);
        break;
      case 'nuevo':
        productos.sort((a, b) => b.id - a.id);
        break;
      default:
        // Relevancia: productos en oferta primero, luego por rating
        productos.sort((a, b) => {
          if (a.enOferta && !b.enOferta) return -1;
          if (!a.enOferta && b.enOferta) return 1;
          return b.rating - a.rating;
        });
    }

    return productos;
  }, [estado.productos, estado.filtros, ordenamiento]);

  const categorias = estado.configuracion?.configuracion.categorias || [];
  const subcategorias = categorias.find(c => c.id === estado.filtros.categoria)?.subcategorias || [];

  const manejarFiltro = (filtro: string, valor: any) => {
    dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { [filtro]: valor } });
  };

  const limpiarFiltros = () => {
    dispatch({ 
      type: 'ACTUALIZAR_FILTROS', 
      payload: { 
        categoria: '', 
        subcategoria: '', 
        precioMin: 0, 
        precioMax: 1000, 
        talla: '', 
        color: '', 
        busqueda: '' 
      } 
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {estado.filtros.categoria 
                ? categorias.find(c => c.id === estado.filtros.categoria)?.nombre || 'Catálogo'
                : 'Catálogo de Productos'
              }
            </h1>
            <p className="text-gray-600">
              {productosFiltrados.length} productos encontrados
            </p>
          </div>

          <div className="flex items-center space-x-4 mt-4 lg:mt-0">
            {/* Botón de filtros móvil */}
            <button
              onClick={() => setMostrarFiltros(!mostrarFiltros)}
              className="lg:hidden bg-white border border-gray-300 px-4 py-2 rounded-lg flex items-center"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filtros
            </button>

            {/* Ordenamiento */}
            <select
              value={ordenamiento}
              onChange={(e) => setOrdenamiento(e.target.value)}
              className="bg-white border border-gray-300 px-4 py-2 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            >
              <option value="relevancia">Relevancia</option>
              <option value="precio-asc">Precio: Menor a Mayor</option>
              <option value="precio-desc">Precio: Mayor a Menor</option>
              <option value="nombre">Nombre A-Z</option>
              <option value="rating">Mejor Valorados</option>
              <option value="nuevo">Más Nuevos</option>
            </select>

            {/* Vista */}
            <div className="hidden sm:flex bg-white border border-gray-300 rounded-lg">
              <button
                onClick={() => setVistaGrid(true)}
                className={`p-2 ${vistaGrid ? 'bg-primary-50 text-primary-600' : 'text-gray-400'}`}
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setVistaGrid(false)}
                className={`p-2 ${!vistaGrid ? 'bg-primary-50 text-primary-600' : 'text-gray-400'}`}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Panel de filtros */}
          <div className={`lg:w-1/4 ${mostrarFiltros ? 'block' : 'hidden lg:block'}`}>
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                  <SlidersHorizontal className="h-5 w-5 mr-2" />
                  Filtros
                </h2>
                <button
                  onClick={limpiarFiltros}
                  className="text-sm text-primary-600 hover:text-primary-700"
                >
                  Limpiar
                </button>
              </div>

              {/* Categorías */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-900 mb-3">Categoría</h3>
                <div className="space-y-2">
                  {categorias.map((categoria) => (
                    <label key={categoria.id} className="flex items-center">
                      <input
                        type="radio"
                        name="categoria"
                        checked={estado.filtros.categoria === categoria.id}
                        onChange={() => manejarFiltro('categoria', categoria.id)}
                        className="mr-2 text-primary-600 focus:ring-primary-500"
                      />
                      <span className="text-sm text-gray-700">{categoria.nombre}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Subcategorías */}
              {subcategorias.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-medium text-gray-900 mb-3">Tipo</h3>
                  <div className="space-y-2">
                    {subcategorias.map((subcategoria) => (
                      <label key={subcategoria} className="flex items-center">
                        <input
                          type="radio"
                          name="subcategoria"
                          checked={estado.filtros.subcategoria === subcategoria}
                          onChange={() => manejarFiltro('subcategoria', subcategoria)}
                          className="mr-2 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="text-sm text-gray-700 capitalize">{subcategoria}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Rango de precio */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-900 mb-3">Precio</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Mínimo</label>
                    <input
                      type="range"
                      min="0"
                      max="200"
                      value={estado.filtros.precioMin}
                      onChange={(e) => manejarFiltro('precioMin', parseInt(e.target.value))}
                      className="w-full"
                    />
                    <span className="text-sm text-gray-500">€{estado.filtros.precioMin}</span>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Máximo</label>
                    <input
                      type="range"
                      min="0"
                      max="200"
                      value={estado.filtros.precioMax}
                      onChange={(e) => manejarFiltro('precioMax', parseInt(e.target.value))}
                      className="w-full"
                    />
                    <span className="text-sm text-gray-500">€{estado.filtros.precioMax}</span>
                  </div>
                </div>
              </div>

              {/* Tallas */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-900 mb-3">Talla</h3>
                <div className="grid grid-cols-3 gap-2">
                  {['XS', 'S', 'M', 'L', 'XL', 'XXL'].map((talla) => (
                    <button
                      key={talla}
                      onClick={() => manejarFiltro('talla', estado.filtros.talla === talla ? '' : talla)}
                      className={`py-2 px-3 text-sm border rounded-md ${
                        estado.filtros.talla === talla
                          ? 'border-primary-600 bg-primary-50 text-primary-700'
                          : 'border-gray-300 text-gray-700 hover:border-gray-400'
                      }`}
                    >
                      {talla}
                    </button>
                  ))}
                </div>
              </div>

              {/* Colores */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-900 mb-3">Color</h3>
                <div className="space-y-2">
                  {['Blanco', 'Negro', 'Azul', 'Rosa', 'Gris', 'Rojo'].map((color) => (
                    <label key={color} className="flex items-center">
                      <input
                        type="radio"
                        name="color"
                        checked={estado.filtros.color === color}
                        onChange={() => manejarFiltro('color', estado.filtros.color === color ? '' : color)}
                        className="mr-2 text-primary-600 focus:ring-primary-500"
                      />
                      <span className="text-sm text-gray-700">{color}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Productos */}
          <div className="lg:w-3/4">
            {productosFiltrados.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Filter className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No se encontraron productos
                </h3>
                <p className="text-gray-600 mb-4">
                  Intenta ajustar los filtros o buscar otros términos
                </p>
                <button
                  onClick={limpiarFiltros}
                  className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors"
                >
                  Limpiar Filtros
                </button>
              </div>
            ) : (
              <div className={`grid ${
                vistaGrid 
                  ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6' 
                  : 'grid-cols-1 gap-4'
              }`}>
                {productosFiltrados.map((producto) => (
                  <TarjetaProducto
                    key={producto.id}
                    producto={producto}
                    onVerProducto={(id) => {
                      setProductoSeleccionado(id);
                      setPaginaActual('producto');
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Overlay para filtros móviles */}
      {mostrarFiltros && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setMostrarFiltros(false)}
        >
          <div className="fixed right-0 top-0 h-full w-80 bg-white shadow-xl z-50 overflow-y-auto">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Filtros</h2>
                <button
                  onClick={() => setMostrarFiltros(false)}
                  className="p-2 hover:bg-gray-100 rounded"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="p-4">
              {/* Aquí irían los mismos filtros que en desktop */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
