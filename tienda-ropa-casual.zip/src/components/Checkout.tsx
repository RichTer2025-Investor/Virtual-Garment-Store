import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, QrCode, Lock, CheckCircle, AlertCircle } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface CheckoutProps {
  setPaginaActual: (pagina: string) => void;
}

export const Checkout: React.FC<CheckoutProps> = ({ setPaginaActual }) => {
  const { estado, dispatch } = useTienda();
  const [paso, setPaso] = useState(1);
  const [metodoPago, setMetodoPago] = useState('');
  const [procesandoPago, setProcesandoPago] = useState(false);
  const [pagoCompletado, setPagoCompletado] = useState(false);
  const [codigoPedido, setCodigoPedido] = useState('');

  // Formularios
  const [datosEnvio, setDatosEnvio] = useState({
    nombre: estado.usuario?.nombre || '',
    email: estado.usuario?.email || '',
    telefono: estado.usuario?.telefono || '',
    direccion: estado.usuario?.direccion.calle || '',
    ciudad: estado.usuario?.direccion.ciudad || '',
    codigoPostal: estado.usuario?.direccion.codigoPostal || '',
    pais: estado.usuario?.direccion.pais || 'España',
  });

  const [datosTarjeta, setDatosTarjeta] = useState({
    numero: '',
    nombre: '',
    expiracion: '',
    cvv: '',
  });

  const calcularSubtotal = () => {
    return estado.carrito.reduce((total, item) => {
      const precio = item.enOferta 
        ? item.precio * (1 - item.descuento / 100)
        : item.precio;
      return total + (precio * item.cantidad);
    }, 0);
  };

  const calcularEnvio = () => {
    const subtotal = calcularSubtotal();
    const envioGratis = estado.configuracion?.configuracion.envioGratis || 50;
    return subtotal >= envioGratis ? 0 : estado.configuracion?.configuracion.costoEnvio || 5.99;
  };

  const calcularTotal = () => {
    return calcularSubtotal() + calcularEnvio();
  };

  const validarPaso1 = () => {
    return datosEnvio.nombre && datosEnvio.email && datosEnvio.telefono && 
           datosEnvio.direccion && datosEnvio.ciudad && datosEnvio.codigoPostal;
  };

  const validarPaso2 = () => {
    if (metodoPago === 'tarjeta') {
      return datosTarjeta.numero && datosTarjeta.nombre && datosTarjeta.expiracion && datosTarjeta.cvv;
    }
    return metodoPago !== '';
  };

  const procesarPago = async () => {
    setProcesandoPago(true);
    
    // Simular procesamiento de pago
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Generar código de pedido
    const nuevoCodigo = `PED-${Date.now().toString().slice(-6)}`;
    setCodigoPedido(nuevoCodigo);
    
    // Crear pedido
    const nuevoPedido = {
      id: nuevoCodigo,
      usuarioId: estado.usuario?.id || 0,
      fecha: new Date().toISOString().split('T')[0],
      estado: 'pendiente' as const,
      productos: estado.carrito.map(item => ({
        id: item.id,
        nombre: item.nombre,
        precio: item.enOferta ? item.precio * (1 - item.descuento / 100) : item.precio,
        cantidad: item.cantidad,
        talla: item.tallaSeleccionada,
        color: item.colorSeleccionado,
      })),
      subtotal: calcularSubtotal(),
      envio: calcularEnvio(),
      total: calcularTotal(),
      direccionEnvio: {
        nombre: datosEnvio.nombre,
        calle: datosEnvio.direccion,
        ciudad: datosEnvio.ciudad,
        codigoPostal: datosEnvio.codigoPostal,
        pais: datosEnvio.pais,
      },
      metodoPago,
      estadosPago: 'completado',
    };

    dispatch({ type: 'AGREGAR_PEDIDO', payload: nuevoPedido });
    dispatch({ type: 'LIMPIAR_CARRITO' });
    
    setProcesandoPago(false);
    setPagoCompletado(true);
  };

  if (estado.carrito.length === 0 && !pagoCompletado) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <AlertCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Tu carrito está vacío
            </h2>
            <p className="text-gray-600 mb-8">
              No puedes proceder al checkout sin productos en tu carrito.
            </p>
            <button
              onClick={() => setPaginaActual('catalogo')}
              className="w-full bg-primary-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors"
            >
              Ir al Catálogo
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (pagoCompletado) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              ¡Pago Completado!
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Tu pedido ha sido procesado exitosamente.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Detalles del Pedido</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Número de pedido:</span>
                  <span className="font-bold">{codigoPedido}</span>
                </div>
                <div className="flex justify-between">
                  <span>Total pagado:</span>
                  <span className="font-bold">€{calcularTotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Método de pago:</span>
                  <span className="capitalize">{metodoPago}</span>
                </div>
                <div className="flex justify-between">
                  <span>Dirección de envío:</span>
                  <span>{datosEnvio.direccion}, {datosEnvio.ciudad}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600">
                Recibirás un email de confirmación en {datosEnvio.email} con todos los detalles 
                de tu pedido y el seguimiento del envío.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => setPaginaActual('inicio')}
                  className="bg-primary-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors"
                >
                  Volver al Inicio
                </button>
                <button
                  onClick={() => setPaginaActual('catalogo')}
                  className="border border-primary-600 text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-primary-50 transition-colors"
                >
                  Seguir Comprando
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => setPaginaActual('carrito')}
            className="flex items-center text-primary-600 hover:text-primary-700 mb-4 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver al carrito
          </button>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Finalizar Compra</h1>
          
          {/* Indicador de pasos */}
          <div className="flex items-center space-x-4 mb-8">
            <div className={`flex items-center ${paso >= 1 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                paso >= 1 ? 'bg-primary-600 text-white' : 'bg-gray-200'
              }`}>
                1
              </div>
              <span className="ml-2 hidden sm:inline">Datos de Envío</span>
            </div>
            <div className="w-8 h-px bg-gray-300"></div>
            <div className={`flex items-center ${paso >= 2 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                paso >= 2 ? 'bg-primary-600 text-white' : 'bg-gray-200'
              }`}>
                2
              </div>
              <span className="ml-2 hidden sm:inline">Método de Pago</span>
            </div>
            <div className="w-8 h-px bg-gray-300"></div>
            <div className={`flex items-center ${paso >= 3 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                paso >= 3 ? 'bg-primary-600 text-white' : 'bg-gray-200'
              }`}>
                3
              </div>
              <span className="ml-2 hidden sm:inline">Confirmación</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulario principal */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-6">
              {/* Paso 1: Datos de envío */}
              {paso === 1 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Datos de Envío</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nombre completo *
                      </label>
                      <input
                        type="text"
                        value={datosEnvio.nombre}
                        onChange={(e) => setDatosEnvio({...datosEnvio, nombre: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        value={datosEnvio.email}
                        onChange={(e) => setDatosEnvio({...datosEnvio, email: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Teléfono *
                      </label>
                      <input
                        type="tel"
                        value={datosEnvio.telefono}
                        onChange={(e) => setDatosEnvio({...datosEnvio, telefono: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Dirección *
                      </label>
                      <input
                        type="text"
                        value={datosEnvio.direccion}
                        onChange={(e) => setDatosEnvio({...datosEnvio, direccion: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Ciudad *
                      </label>
                      <input
                        type="text"
                        value={datosEnvio.ciudad}
                        onChange={(e) => setDatosEnvio({...datosEnvio, ciudad: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Código Postal *
                      </label>
                      <input
                        type="text"
                        value={datosEnvio.codigoPostal}
                        onChange={(e) => setDatosEnvio({...datosEnvio, codigoPostal: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        required
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => setPaso(2)}
                    disabled={!validarPaso1()}
                    className="mt-6 w-full bg-primary-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    Continuar al Pago
                  </button>
                </div>
              )}

              {/* Paso 2: Método de pago */}
              {paso === 2 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Método de Pago</h2>
                  
                  {/* Opciones de pago */}
                  <div className="space-y-4 mb-6">
                    <label className="flex items-center p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="metodoPago"
                        value="tarjeta"
                        checked={metodoPago === 'tarjeta'}
                        onChange={(e) => setMetodoPago(e.target.value)}
                        className="mr-3"
                      />
                      <CreditCard className="h-6 w-6 text-gray-600 mr-3" />
                      <div>
                        <div className="font-medium">Tarjeta de Crédito/Débito</div>
                        <div className="text-sm text-gray-500">Visa, Mastercard, American Express</div>
                      </div>
                    </label>
                    
                    <label className="flex items-center p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="metodoPago"
                        value="paypal"
                        checked={metodoPago === 'paypal'}
                        onChange={(e) => setMetodoPago(e.target.value)}
                        className="mr-3"
                      />
                      <Smartphone className="h-6 w-6 text-blue-600 mr-3" />
                      <div>
                        <div className="font-medium">PayPal</div>
                        <div className="text-sm text-gray-500">Pago seguro con tu cuenta PayPal</div>
                      </div>
                    </label>
                    
                    <label className="flex items-center p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                      <input
                        type="radio"
                        name="metodoPago"
                        value="qr"
                        checked={metodoPago === 'qr'}
                        onChange={(e) => setMetodoPago(e.target.value)}
                        className="mr-3"
                      />
                      <QrCode className="h-6 w-6 text-gray-600 mr-3" />
                      <div>
                        <div className="font-medium">Código QR</div>
                        <div className="text-sm text-gray-500">Pago móvil con código QR</div>
                      </div>
                    </label>
                  </div>

                  {/* Formulario de tarjeta */}
                  {metodoPago === 'tarjeta' && (
                    <div className="space-y-4 mb-6 p-4 bg-gray-50 rounded-lg">
                      <h3 className="font-medium text-gray-900">Datos de la Tarjeta</h3>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Número de tarjeta
                        </label>
                        <input
                          type="text"
                          placeholder="1234 5678 9012 3456"
                          value={datosTarjeta.numero}
                          onChange={(e) => setDatosTarjeta({...datosTarjeta, numero: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Nombre en la tarjeta
                        </label>
                        <input
                          type="text"
                          value={datosTarjeta.nombre}
                          onChange={(e) => setDatosTarjeta({...datosTarjeta, nombre: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Expiración
                          </label>
                          <input
                            type="text"
                            placeholder="MM/AA"
                            value={datosTarjeta.expiracion}
                            onChange={(e) => setDatosTarjeta({...datosTarjeta, expiracion: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            CVV
                          </label>
                          <input
                            type="text"
                            placeholder="123"
                            value={datosTarjeta.cvv}
                            onChange={(e) => setDatosTarjeta({...datosTarjeta, cvv: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-4">
                    <button
                      onClick={() => setPaso(1)}
                      className="flex-1 border border-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                    >
                      Atrás
                    </button>
                    <button
                      onClick={() => setPaso(3)}
                      disabled={!validarPaso2()}
                      className="flex-1 bg-primary-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                      Revisar Pedido
                    </button>
                  </div>
                </div>
              )}

              {/* Paso 3: Confirmación */}
              {paso === 3 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Confirmar Pedido</h2>
                  
                  {/* Resumen de datos */}
                  <div className="space-y-6">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-medium text-gray-900 mb-2">Dirección de Envío</h3>
                      <p className="text-sm text-gray-600">
                        {datosEnvio.nombre}<br />
                        {datosEnvio.direccion}<br />
                        {datosEnvio.ciudad}, {datosEnvio.codigoPostal}<br />
                        {datosEnvio.telefono}
                      </p>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-medium text-gray-900 mb-2">Método de Pago</h3>
                      <p className="text-sm text-gray-600 capitalize">
                        {metodoPago === 'tarjeta' && '💳 Tarjeta de Crédito/Débito'}
                        {metodoPago === 'paypal' && '🟡 PayPal'}
                        {metodoPago === 'qr' && '📱 Código QR'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center mt-6 p-4 bg-blue-50 rounded-lg">
                    <Lock className="h-5 w-5 text-blue-600 mr-2" />
                    <span className="text-sm text-blue-800">
                      Tu información está protegida con encriptación SSL
                    </span>
                  </div>

                  <div className="flex space-x-4 mt-6">
                    <button
                      onClick={() => setPaso(2)}
                      className="flex-1 border border-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                    >
                      Atrás
                    </button>
                    <button
                      onClick={procesarPago}
                      disabled={procesandoPago}
                      className="flex-1 bg-green-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                      {procesandoPago ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Procesando...
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Confirmar y Pagar
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Resumen del pedido */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Resumen del Pedido</h2>
              
              {/* Productos */}
              <div className="space-y-4 mb-6">
                {estado.carrito.map((item, index) => {
                  const precioFinal = item.enOferta 
                    ? item.precio * (1 - item.descuento / 100)
                    : item.precio;

                  return (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-xs">#{item.id}</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-gray-900">{item.nombre}</h4>
                        <p className="text-xs text-gray-500">
                          {item.tallaSeleccionada} · {item.colorSeleccionado} · Cant: {item.cantidad}
                        </p>
                      </div>
                      <span className="text-sm font-semibold">
                        €{(precioFinal * item.cantidad).toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>

              <hr className="border-gray-200 mb-4" />
              
              {/* Totales */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span>€{calcularSubtotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Envío</span>
                  <span>{calcularEnvio() === 0 ? 'Gratis' : `€${calcularEnvio().toFixed(2)}`}</span>
                </div>
                <hr className="border-gray-200" />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span>€{calcularTotal().toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
