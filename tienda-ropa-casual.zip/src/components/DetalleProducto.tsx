import React, { useState } from 'react';
import { ArrowLeft, Star, ShoppingCart, Heart, Share2, Truck, Shield, RefreshCw, Plus, Minus } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface DetalleProductoProps {
  productoId: number;
  setPaginaActual: (pagina: string) => void;
  setProductoSeleccionado?: (id: number) => void;
}

export const DetalleProducto: React.FC<DetalleProductoProps> = ({ productoId, setPaginaActual, setProductoSeleccionado }) => {
  const { estado, dispatch } = useTienda();
  const [tallaSeleccionada, setTallaSeleccionada] = useState('');
  const [colorSeleccionado, setColorSeleccionado] = useState('');
  const [cantidad, setCantidad] = useState(1);
  const [imagenSeleccionada, setImagenSeleccionada] = useState(0);
  const [mostrarReseñas, setMostrarReseñas] = useState(false);

  const producto = estado.productos.find(p => p.id === productoId);

  if (!producto) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Producto no encontrado</h2>
          <button
            onClick={() => setPaginaActual('catalogo')}
            className="bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition-colors"
          >
            Volver al catálogo
          </button>
        </div>
      </div>
    );
  }

  const precioFinal = producto.enOferta 
    ? producto.precio * (1 - producto.descuento / 100)
    : producto.precio;

  const manejarAgregarAlCarrito = () => {
    if (!tallaSeleccionada || !colorSeleccionado) {
      alert('Por favor selecciona una talla y un color');
      return;
    }

    dispatch({
      type: 'AGREGAR_AL_CARRITO',
      payload: {
        ...producto,
        cantidad,
        tallaSeleccionada,
        colorSeleccionado,
      }
    });

    alert('Producto agregado al carrito');
  };

  const productosRelacionados = estado.productos
    .filter(p => p.categoria === producto.categoria && p.id !== producto.id)
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-gray-500 mb-8">
          <button
            onClick={() => setPaginaActual('catalogo')}
            className="hover:text-primary-600 transition-colors"
          >
            Catálogo
          </button>
          <span>/</span>
          <span className="capitalize">{producto.categoria}</span>
          <span>/</span>
          <span className="text-gray-900">{producto.nombre}</span>
        </div>

        {/* Botón volver */}
        <button
          onClick={() => setPaginaActual('catalogo')}
          className="flex items-center text-primary-600 hover:text-primary-700 mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Volver al catálogo
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Galería de imágenes */}
          <div className="space-y-4">
            <div className="aspect-square bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg overflow-hidden">
              <div className="h-full flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShoppingCart className="h-12 w-12 text-primary-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-700 mb-2">{producto.nombre}</h3>
                  <p className="text-gray-600">{producto.categoria}</p>
                </div>
              </div>
            </div>

            {/* Miniaturas */}
            <div className="grid grid-cols-4 gap-2">
              {[...Array(4)].map((_, index) => (
                <button
                  key={index}
                  onClick={() => setImagenSeleccionada(index)}
                  className={`aspect-square bg-gradient-to-br from-primary-50 to-secondary-50 rounded-lg border-2 ${
                    imagenSeleccionada === index ? 'border-primary-600' : 'border-gray-200'
                  } hover:border-primary-400 transition-colors`}
                >
                  <div className="h-full flex items-center justify-center">
                    <ShoppingCart className="h-6 w-6 text-primary-600" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Información del producto */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{producto.nombre}</h1>
              <p className="text-lg text-gray-600">{producto.descripcion}</p>
            </div>

            {/* Rating y reseñas */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(producto.rating)
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-gray-600">{producto.rating}/5</span>
              <button
                onClick={() => setMostrarReseñas(!mostrarReseñas)}
                className="text-primary-600 hover:text-primary-700 underline"
              >
                {producto.reviews} reseñas
              </button>
            </div>

            {/* Precio */}
            <div className="space-y-2">
              {producto.enOferta ? (
                <div className="flex items-center space-x-3">
                  <span className="text-3xl font-bold text-secondary-600">
                    €{precioFinal.toFixed(2)}
                  </span>
                  <span className="text-xl text-gray-500 line-through">
                    €{producto.precio.toFixed(2)}
                  </span>
                  <span className="bg-secondary-100 text-secondary-800 px-3 py-1 rounded-full text-sm font-bold">
                    -{producto.descuento}% OFF
                  </span>
                </div>
              ) : (
                <span className="text-3xl font-bold text-gray-900">
                  €{producto.precio.toFixed(2)}
                </span>
              )}
              <p className="text-sm text-gray-500">Envío gratis en compras superiores a €50</p>
            </div>

            {/* Selector de talla */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-900">Talla</h3>
              <div className="grid grid-cols-6 gap-2">
                {producto.tallas.map((talla) => (
                  <button
                    key={talla}
                    onClick={() => setTallaSeleccionada(talla)}
                    className={`py-3 px-4 border rounded-lg text-center font-medium ${
                      tallaSeleccionada === talla
                        ? 'border-primary-600 bg-primary-50 text-primary-700'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    } transition-colors`}
                  >
                    {talla}
                  </button>
                ))}
              </div>
            </div>

            {/* Selector de color */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-900">Color</h3>
              <div className="space-y-2">
                {producto.colores.map((color) => (
                  <label key={color} className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="color"
                      checked={colorSeleccionado === color}
                      onChange={() => setColorSeleccionado(color)}
                      className="text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-gray-700">{color}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Selector de cantidad */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-900">Cantidad</h3>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setCantidad(Math.max(1, cantidad - 1))}
                  className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={cantidad <= 1}
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="text-lg font-semibold w-8 text-center">{cantidad}</span>
                <button
                  onClick={() => setCantidad(Math.min(producto.stock, cantidad + 1))}
                  className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  disabled={cantidad >= producto.stock}
                >
                  <Plus className="h-4 w-4" />
                </button>
                <span className="text-sm text-gray-500">
                  ({producto.stock} disponibles)
                </span>
              </div>
            </div>

            {/* Botones de acción */}
            <div className="space-y-4">
              <button
                onClick={manejarAgregarAlCarrito}
                disabled={producto.stock === 0}
                className="w-full bg-primary-600 text-white py-4 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                {producto.stock === 0 ? 'Agotado' : 'Agregar al Carrito'}
              </button>

              <div className="flex space-x-4">
                <button className="flex-1 border border-gray-300 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center">
                  <Heart className="h-5 w-5 mr-2" />
                  Favoritos
                </button>
                <button className="flex-1 border border-gray-300 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center">
                  <Share2 className="h-5 w-5 mr-2" />
                  Compartir
                </button>
              </div>
            </div>

            {/* Información de envío y garantías */}
            <div className="space-y-4 pt-6 border-t border-gray-200">
              <div className="flex items-center space-x-3">
                <Truck className="h-5 w-5 text-green-600" />
                <span className="text-sm text-gray-700">Envío gratis en compras superiores a €50</span>
              </div>
              <div className="flex items-center space-x-3">
                <Shield className="h-5 w-5 text-blue-600" />
                <span className="text-sm text-gray-700">Compra 100% segura</span>
              </div>
              <div className="flex items-center space-x-3">
                <RefreshCw className="h-5 w-5 text-purple-600" />
                <span className="text-sm text-gray-700">Devoluciones gratuitas hasta 30 días</span>
              </div>
            </div>
          </div>
        </div>

        {/* Reseñas */}
        {mostrarReseñas && (
          <div className="mt-16 bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Reseñas de Clientes</h2>
            <div className="space-y-6">
              {[...Array(3)].map((_, index) => (
                <div key={index} className="border-b border-gray-200 pb-6">
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                      <span className="text-primary-600 font-semibold">U</span>
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-gray-900">Usuario {index + 1}</span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < 5 ? 'text-yellow-400 fill-current' : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-sm text-gray-500">Hace 2 semanas</span>
                    </div>
                  </div>
                  <p className="text-gray-700">
                    Excelente producto, muy buena calidad y el envío fue rápido. 
                    La talla es perfecta y el color es exactamente como se ve en las fotos.
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Productos relacionados */}
        {productosRelacionados.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Productos Relacionados</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {productosRelacionados.map((productoRel) => (
                <div key={productoRel.id} className="bg-white rounded-lg shadow-md p-4">
                  <div className="aspect-square bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg mb-4 flex items-center justify-center">
                    <ShoppingCart className="h-8 w-8 text-primary-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{productoRel.nombre}</h3>
                  <p className="text-primary-600 font-bold">€{productoRel.precio.toFixed(2)}</p>
                  <button
                    onClick={() => {
                      if (setProductoSeleccionado) {
                        setProductoSeleccionado(productoRel.id);
                        window.scrollTo(0, 0);
                      }
                    }}
                    className="w-full mt-3 bg-primary-600 text-white py-2 rounded-lg hover:bg-primary-700 transition-colors"
                  >
                    Ver Producto
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
