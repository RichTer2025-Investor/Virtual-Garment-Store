import React from 'react';
import { Mail, Phone, MapPin, Facebook, Instagram, Twitter, CreditCard, Truck, Shield, RotateCcw } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface FooterProps {
  setPaginaActual: (pagina: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setPaginaActual }) => {
  const { estado } = useTienda();
  const configuracion = estado.configuracion;

  return (
    <footer className="bg-gray-900 text-white">
      {/* Sección principal del footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Información de la empresa */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white mb-4">
              {configuracion?.tienda.nombre || 'Casual Style'}
            </h3>
            <p className="text-gray-300 text-sm">
              {configuracion?.tienda.descripcion || 'Tu tienda de ropa casual favorita'}
            </p>
            
            <div className="space-y-2">
              <div className="flex items-center text-gray-300 text-sm">
                <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>{configuracion?.tienda.contacto.direccion || 'Calle de la Moda 123, Madrid'}</span>
              </div>
              <div className="flex items-center text-gray-300 text-sm">
                <Phone className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>{configuracion?.tienda.contacto.telefono || '+34 900 123 456'}</span>
              </div>
              <div className="flex items-center text-gray-300 text-sm">
                <Mail className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>{configuracion?.tienda.contacto.email || 'contacto@casualstyle.com'}</span>
              </div>
            </div>

            {/* Redes sociales */}
            <div className="flex space-x-4 pt-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Enlaces rápidos */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">Enlaces Rápidos</h3>
            <div className="space-y-2">
              <button
                onClick={() => setPaginaActual('catalogo')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Catálogo
              </button>
              <button
                onClick={() => setPaginaActual('ofertas')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Ofertas
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Sobre Nosotros
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Contacto
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Blog
              </button>
            </div>
          </div>

          {/* Categorías */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">Categorías</h3>
            <div className="space-y-2">
              {configuracion?.configuracion.categorias.map((categoria) => (
                <button
                  key={categoria.id}
                  onClick={() => {
                    setPaginaActual('catalogo');
                    // Aquí iría la lógica para filtrar por categoría
                  }}
                  className="block text-gray-300 hover:text-white text-sm transition-colors capitalize"
                >
                  {categoria.nombre}
                </button>
              ))}
            </div>
          </div>

          {/* Atención al cliente */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">Atención al Cliente</h3>
            <div className="space-y-2">
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Preguntas Frecuentes
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Guía de Tallas
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Política de Devoluciones
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Envíos y Entregas
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="block text-gray-300 hover:text-white text-sm transition-colors"
              >
                Política de Privacidad
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Beneficios y garantías */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-center space-x-3">
              <div className="bg-primary-600 p-2 rounded-full">
                <Truck className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="text-white font-medium text-sm">Envío Gratis</div>
                <div className="text-gray-400 text-xs">En compras superiores a €50</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="bg-secondary-600 p-2 rounded-full">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="text-white font-medium text-sm">Compra Segura</div>
                <div className="text-gray-400 text-xs">Protección 100% garantizada</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="bg-accent-600 p-2 rounded-full">
                <RotateCcw className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="text-white font-medium text-sm">Devoluciones</div>
                <div className="text-gray-400 text-xs">30 días para devolver</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="bg-green-600 p-2 rounded-full">
                <CreditCard className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="text-white font-medium text-sm">Pago Seguro</div>
                <div className="text-gray-400 text-xs">Múltiples métodos</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-white mb-2">
              Suscríbete a nuestro Newsletter
            </h3>
            <p className="text-gray-400 text-sm mb-6">
              Recibe ofertas exclusivas y las últimas tendencias en moda
            </p>
            
            <div className="max-w-md mx-auto flex space-x-4">
              <input
                type="email"
                placeholder="Tu email"
                className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
              <button className="bg-primary-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors">
                Suscribirse
              </button>
            </div>
            
            <p className="text-gray-500 text-xs mt-3">
              No compartimos tu información. Puedes darte de baja en cualquier momento.
            </p>
          </div>
        </div>
      </div>

      {/* Métodos de pago */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <div className="text-center sm:text-left mb-4 sm:mb-0">
              <h4 className="text-white font-medium text-sm mb-2">Métodos de Pago Aceptados</h4>
              <div className="flex justify-center sm:justify-start space-x-4">
                <div className="bg-gray-800 px-3 py-2 rounded text-white text-xs font-medium">
                  💳 Tarjetas
                </div>
                <div className="bg-gray-800 px-3 py-2 rounded text-white text-xs font-medium">
                  🟡 PayPal
                </div>
                <div className="bg-gray-800 px-3 py-2 rounded text-white text-xs font-medium">
                  📱 QR
                </div>
              </div>
            </div>
            
            <div className="text-center sm:text-right">
              <div className="text-gray-400 text-xs">
                <p>Horario de atención:</p>
                <p>Lunes a Viernes: 9:00 - 18:00</p>
                <p>Sábados: 10:00 - 14:00</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 {configuracion?.tienda.nombre || 'Casual Style'}. Todos los derechos reservados.
            </div>
            
            <div className="flex space-x-6 text-sm">
              <button
                onClick={() => setPaginaActual('inicio')}
                className="text-gray-400 hover:text-white transition-colors"
              >
                Términos y Condiciones
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="text-gray-400 hover:text-white transition-colors"
              >
                Política de Privacidad
              </button>
              <button
                onClick={() => setPaginaActual('inicio')}
                className="text-gray-400 hover:text-white transition-colors"
              >
                Cookies
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
