import React, { useState } from 'react';
import { Eye, EyeOff, Mail, Lock, User, Phone, MapPin } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface LoginProps {
  setPaginaActual: (pagina: string) => void;
}

export const Login: React.FC<LoginProps> = ({ setPaginaActual }) => {
  const { estado, dispatch } = useTienda();
  const [modoRegistro, setModoRegistro] = useState(false);
  const [mostrarPassword, setMostrarPassword] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');

  const [datosLogin, setDatosLogin] = useState({
    email: '',
    password: '',
  });

  const [datosRegistro, setDatosRegistro] = useState({
    nombre: '',
    email: '',
    telefono: '',
    password: '',
    confirmarPassword: '',
    direccion: {
      calle: '',
      ciudad: '',
      codigoPostal: '',
      pais: 'España',
    },
  });

  // Cargar usuarios desde el JSON
  const cargarUsuarios = async () => {
    try {
      const response = await fetch('/usuarios.json');
      const usuarios = await response.json();
      return usuarios;
    } catch (error) {
      console.error('Error cargando usuarios:', error);
      return [];
    }
  };

  const manejarLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCargando(true);
    setError('');

    try {
      const usuarios = await cargarUsuarios();
      
      // Buscar usuario por email
      const usuario = usuarios.find((u: any) => u.email === datosLogin.email);
      
      if (!usuario) {
        setError('Usuario no encontrado');
        setCargando(false);
        return;
      }

      // En un sistema real, aquí verificarías la contraseña
      // Por simplicidad, aceptamos cualquier contraseña para usuarios existentes
      if (datosLogin.password.length < 6) {
        setError('Contraseña inválida');
        setCargando(false);
        return;
      }

      // Simular delay de autenticación
      await new Promise(resolve => setTimeout(resolve, 1000));

      dispatch({ type: 'INICIAR_SESION', payload: usuario });
      setPaginaActual('inicio');
      
    } catch (error) {
      setError('Error al iniciar sesión');
    }
    
    setCargando(false);
  };

  const manejarRegistro = async (e: React.FormEvent) => {
    e.preventDefault();
    setCargando(true);
    setError('');

    // Validaciones
    if (datosRegistro.password !== datosRegistro.confirmarPassword) {
      setError('Las contraseñas no coinciden');
      setCargando(false);
      return;
    }

    if (datosRegistro.password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      setCargando(false);
      return;
    }

    if (!datosRegistro.nombre || !datosRegistro.email || !datosRegistro.telefono) {
      setError('Por favor completa todos los campos requeridos');
      setCargando(false);
      return;
    }

    try {
      const usuarios = await cargarUsuarios();
      
      // Verificar si el email ya existe
      const usuarioExistente = usuarios.find((u: any) => u.email === datosRegistro.email);
      if (usuarioExistente) {
        setError('Este email ya está registrado');
        setCargando(false);
        return;
      }

      // Simular delay de registro
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Crear nuevo usuario
      const nuevoUsuario = {
        id: Date.now(),
        nombre: datosRegistro.nombre,
        email: datosRegistro.email,
        telefono: datosRegistro.telefono,
        direccion: datosRegistro.direccion,
        fechaRegistro: new Date().toISOString().split('T')[0],
        esAdmin: false,
      };

      dispatch({ type: 'INICIAR_SESION', payload: nuevoUsuario });
      setPaginaActual('inicio');
      
    } catch (error) {
      setError('Error al registrar usuario');
    }
    
    setCargando(false);
  };

  const manejarLoginDemo = () => {
    // Login rápido con usuario demo
    const usuarioDemo = {
      id: 999,
      nombre: 'Usuario Demo',
      email: 'demo@ejemplo.com',
      telefono: '+34 600 000 000',
      direccion: {
        calle: 'Calle Demo 123',
        ciudad: 'Madrid',
        codigoPostal: '28001',
        pais: 'España'
      },
      fechaRegistro: new Date().toISOString().split('T')[0],
      esAdmin: false,
    };

    dispatch({ type: 'INICIAR_SESION', payload: usuarioDemo });
    setPaginaActual('inicio');
  };

  const manejarLoginAdmin = () => {
    // Login rápido como administrador
    const adminDemo = {
      id: 1000,
      nombre: 'Administrador',
      email: 'admin@tienda.com',
      telefono: '+34 600 000 001',
      direccion: {
        calle: 'Oficina Central',
        ciudad: 'Madrid',
        codigoPostal: '28000',
        pais: 'España'
      },
      fechaRegistro: '2024-01-01',
      esAdmin: true,
    };

    dispatch({ type: 'INICIAR_SESION', payload: adminDemo });
    setPaginaActual('inicio');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-secondary-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {modoRegistro ? 'Crear Cuenta' : 'Iniciar Sesión'}
            </h2>
            <p className="text-gray-600">
              {modoRegistro 
                ? 'Únete a nuestra comunidad y disfruta de beneficios exclusivos' 
                : 'Accede a tu cuenta para una experiencia personalizada'
              }
            </p>
          </div>

          {/* Error */}
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
              {error}
            </div>
          )}

          {/* Formulario */}
          <form onSubmit={modoRegistro ? manejarRegistro : manejarLogin} className="space-y-6">
            {modoRegistro && (
              <>
                {/* Nombre */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre completo *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={datosRegistro.nombre}
                      onChange={(e) => setDatosRegistro({...datosRegistro, nombre: e.target.value})}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="Tu nombre completo"
                      required
                    />
                  </div>
                </div>

                {/* Teléfono */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Teléfono *
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      type="tel"
                      value={datosRegistro.telefono}
                      onChange={(e) => setDatosRegistro({...datosRegistro, telefono: e.target.value})}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="+34 600 000 000"
                      required
                    />
                  </div>
                </div>

                {/* Dirección */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Dirección
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        value={datosRegistro.direccion.calle}
                        onChange={(e) => setDatosRegistro({
                          ...datosRegistro, 
                          direccion: {...datosRegistro.direccion, calle: e.target.value}
                        })}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Calle y número"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      value={datosRegistro.direccion.ciudad}
                      onChange={(e) => setDatosRegistro({
                        ...datosRegistro, 
                        direccion: {...datosRegistro.direccion, ciudad: e.target.value}
                      })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="Ciudad"
                    />
                    <input
                      type="text"
                      value={datosRegistro.direccion.codigoPostal}
                      onChange={(e) => setDatosRegistro({
                        ...datosRegistro, 
                        direccion: {...datosRegistro.direccion, codigoPostal: e.target.value}
                      })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="C.P."
                    />
                  </div>
                </div>
              </>
            )}

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email *
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type="email"
                  value={modoRegistro ? datosRegistro.email : datosLogin.email}
                  onChange={(e) => modoRegistro 
                    ? setDatosRegistro({...datosRegistro, email: e.target.value})
                    : setDatosLogin({...datosLogin, email: e.target.value})
                  }
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="tu@email.com"
                  required
                />
              </div>
            </div>

            {/* Contraseña */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contraseña *
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type={mostrarPassword ? 'text' : 'password'}
                  value={modoRegistro ? datosRegistro.password : datosLogin.password}
                  onChange={(e) => modoRegistro 
                    ? setDatosRegistro({...datosRegistro, password: e.target.value})
                    : setDatosLogin({...datosLogin, password: e.target.value})
                  }
                  className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setMostrarPassword(!mostrarPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                >
                  {mostrarPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Confirmar contraseña (solo registro) */}
            {modoRegistro && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Confirmar Contraseña *
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type={mostrarPassword ? 'text' : 'password'}
                    value={datosRegistro.confirmarPassword}
                    onChange={(e) => setDatosRegistro({...datosRegistro, confirmarPassword: e.target.value})}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>
            )}

            {/* Botón enviar */}
            <button
              type="submit"
              disabled={cargando}
              className="w-full bg-primary-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {cargando ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  {modoRegistro ? 'Creando cuenta...' : 'Iniciando sesión...'}
                </>
              ) : (
                modoRegistro ? 'Crear Cuenta' : 'Iniciar Sesión'
              )}
            </button>
          </form>

          {/* Botones demo */}
          <div className="mt-6 space-y-3">
            <div className="text-center text-sm text-gray-500 mb-3">
              Para pruebas rápidas:
            </div>
            
            <button
              onClick={manejarLoginDemo}
              className="w-full bg-secondary-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-secondary-700 transition-colors"
            >
              Entrar como Usuario Demo
            </button>
            
            <button
              onClick={manejarLoginAdmin}
              className="w-full bg-accent-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-accent-700 transition-colors"
            >
              Entrar como Administrador
            </button>
          </div>

          {/* Toggle modo */}
          <div className="mt-8 text-center">
            <p className="text-gray-600">
              {modoRegistro ? '¿Ya tienes una cuenta?' : '¿No tienes una cuenta?'}
              {' '}
              <button
                onClick={() => {
                  setModoRegistro(!modoRegistro);
                  setError('');
                }}
                className="text-primary-600 hover:text-primary-700 font-medium"
              >
                {modoRegistro ? 'Iniciar Sesión' : 'Crear Cuenta'}
              </button>
            </p>
          </div>

          {/* Compra como invitado */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <button
              onClick={() => setPaginaActual('catalogo')}
              className="w-full text-gray-600 hover:text-gray-800 font-medium transition-colors"
            >
              Continuar sin crear cuenta
            </button>
          </div>
        </div>

        {/* Información adicional */}
        <div className="text-center text-sm text-gray-500">
          <p>Al crear una cuenta, aceptas nuestros términos y condiciones.</p>
          <p className="mt-2">Datos usuarios demo: ana.garcia@email.com | carlos.lopez@email.com</p>
        </div>
      </div>
    </div>
  );
};
