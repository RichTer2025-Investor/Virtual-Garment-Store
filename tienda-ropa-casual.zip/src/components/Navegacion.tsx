import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, X, Heart } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface NavegacionProps {
  paginaActual: string;
  setPaginaActual: (pagina: string) => void;
}

export const Navegacion: React.FC<NavegacionProps> = ({ paginaActual, setPaginaActual }) => {
  const { estado, dispatch } = useTienda();
  const [menuAbierto, setMenuAbierto] = useState(false);
  const [busqueda, setBusqueda] = useState('');

  const totalCarrito = estado.carrito.reduce((total, item) => total + item.cantidad, 0);

  const manejarBusqueda = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { busqueda } });
    setPaginaActual('catalogo');
    setMenuAbierto(false);
  };

  const manejarCerrarSesion = () => {
    dispatch({ type: 'CERRAR_SESION' });
    setPaginaActual('inicio');
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <button
              onClick={() => setPaginaActual('inicio')}
              className="text-2xl font-bold text-primary-600 hover:text-primary-700 transition-colors"
            >
              {estado.configuracion?.tienda.nombre || 'Casual Style'}
            </button>
          </div>

          {/* Navegación principal - Desktop */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => setPaginaActual('catalogo')}
              className={`text-gray-900 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                paginaActual === 'catalogo' ? 'text-primary-600 border-b-2 border-primary-600' : ''
              }`}
            >
              Catálogo
            </button>
            
            <button
              onClick={() => {
                dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { categoria: 'hombre' } });
                setPaginaActual('catalogo');
              }}
              className={`text-gray-900 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                estado.filtros.categoria === 'hombre' ? 'text-primary-600' : ''
              }`}
            >
              Hombre
            </button>
            
            <button
              onClick={() => {
                dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { categoria: 'mujer' } });
                setPaginaActual('catalogo');
              }}
              className={`text-gray-900 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                estado.filtros.categoria === 'mujer' ? 'text-primary-600' : ''
              }`}
            >
              Mujer
            </button>
            
            <button
              onClick={() => setPaginaActual('ofertas')}
              className={`text-secondary-600 hover:text-secondary-700 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                paginaActual === 'ofertas' ? 'text-secondary-700 border-b-2 border-secondary-600' : ''
              }`}
            >
              Ofertas
            </button>
          </div>

          {/* Barra de búsqueda */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <form onSubmit={manejarBusqueda} className="relative w-full">
              <input
                type="text"
                placeholder="Buscar productos..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </form>
          </div>

          {/* Iconos de acción - Desktop */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Wishlist */}
            <button className="text-gray-600 hover:text-primary-600 transition-colors">
              <Heart className="h-6 w-6" />
            </button>

            {/* Usuario */}
            <div className="relative">
              {estado.usuario ? (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-700">
                    Hola, {estado.usuario.nombre.split(' ')[0]}
                  </span>
                  {estado.usuario.esAdmin && (
                    <button
                      onClick={() => setPaginaActual('admin')}
                      className="text-xs bg-accent-100 text-accent-800 px-2 py-1 rounded-full hover:bg-accent-200 transition-colors"
                    >
                      Admin
                    </button>
                  )}
                  <button
                    onClick={manejarCerrarSesion}
                    className="text-sm text-gray-500 hover:text-gray-700 transition-colors"
                  >
                    Salir
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setPaginaActual('login')}
                  className="text-gray-600 hover:text-primary-600 transition-colors"
                >
                  <User className="h-6 w-6" />
                </button>
              )}
            </div>

            {/* Carrito */}
            <button
              onClick={() => setPaginaActual('carrito')}
              className="relative text-gray-600 hover:text-primary-600 transition-colors"
            >
              <ShoppingCart className="h-6 w-6" />
              {totalCarrito > 0 && (
                <span className="absolute -top-2 -right-2 bg-secondary-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {totalCarrito}
                </span>
              )}
            </button>
          </div>

          {/* Botón de menú móvil */}
          <div className="md:hidden">
            <button
              onClick={() => setMenuAbierto(!menuAbierto)}
              className="text-gray-600 hover:text-gray-900 focus:outline-none"
            >
              {menuAbierto ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Menú móvil */}
        {menuAbierto && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t">
              {/* Barra de búsqueda móvil */}
              <form onSubmit={manejarBusqueda} className="relative mb-4">
                <input
                  type="text"
                  placeholder="Buscar productos..."
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </form>

              {/* Enlaces de navegación */}
              <button
                onClick={() => {
                  setPaginaActual('catalogo');
                  setMenuAbierto(false);
                }}
                className="block px-3 py-2 text-base font-medium text-gray-900 hover:text-primary-600 hover:bg-gray-50 rounded-md w-full text-left"
              >
                Catálogo
              </button>
              
              <button
                onClick={() => {
                  dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { categoria: 'hombre' } });
                  setPaginaActual('catalogo');
                  setMenuAbierto(false);
                }}
                className="block px-3 py-2 text-base font-medium text-gray-900 hover:text-primary-600 hover:bg-gray-50 rounded-md w-full text-left"
              >
                Hombre
              </button>
              
              <button
                onClick={() => {
                  dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { categoria: 'mujer' } });
                  setPaginaActual('catalogo');
                  setMenuAbierto(false);
                }}
                className="block px-3 py-2 text-base font-medium text-gray-900 hover:text-primary-600 hover:bg-gray-50 rounded-md w-full text-left"
              >
                Mujer
              </button>
              
              <button
                onClick={() => {
                  setPaginaActual('ofertas');
                  setMenuAbierto(false);
                }}
                className="block px-3 py-2 text-base font-medium text-secondary-600 hover:text-secondary-700 hover:bg-gray-50 rounded-md w-full text-left"
              >
                Ofertas
              </button>

              {/* Acciones del usuario */}
              <div className="border-t pt-4 mt-4">
                {estado.usuario ? (
                  <div className="space-y-2">
                    <div className="px-3 py-2 text-base font-medium text-gray-900">
                      Hola, {estado.usuario.nombre}
                    </div>
                    {estado.usuario.esAdmin && (
                      <button
                        onClick={() => {
                          setPaginaActual('admin');
                          setMenuAbierto(false);
                        }}
                        className="block px-3 py-2 text-base font-medium text-accent-600 hover:text-accent-700 hover:bg-gray-50 rounded-md w-full text-left"
                      >
                        Panel Admin
                      </button>
                    )}
                    <button
                      onClick={() => {
                        manejarCerrarSesion();
                        setMenuAbierto(false);
                      }}
                      className="block px-3 py-2 text-base font-medium text-gray-600 hover:text-gray-700 hover:bg-gray-50 rounded-md w-full text-left"
                    >
                      Cerrar Sesión
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setPaginaActual('login');
                      setMenuAbierto(false);
                    }}
                    className="block px-3 py-2 text-base font-medium text-gray-900 hover:text-primary-600 hover:bg-gray-50 rounded-md w-full text-left"
                  >
                    Iniciar Sesión
                  </button>
                )}
                
                <button
                  onClick={() => {
                    setPaginaActual('carrito');
                    setMenuAbierto(false);
                  }}
                  className="flex items-center px-3 py-2 text-base font-medium text-gray-900 hover:text-primary-600 hover:bg-gray-50 rounded-md w-full"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Carrito ({totalCarrito})
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
