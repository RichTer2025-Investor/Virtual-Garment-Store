import React from 'react';
import { Star, ArrowRight, ShoppingBag, Truck, Shield, RefreshCw } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';
import { TarjetaProducto } from './TarjetaProducto';

interface PaginaInicioProps {
  setPaginaActual: (pagina: string) => void;
  setProductoSeleccionado: (id: number) => void;
}

export const PaginaInicio: React.FC<PaginaInicioProps> = ({ setPaginaActual, setProductoSeleccionado }) => {
  const { estado, dispatch } = useTienda();

  const productosDestacados = estado.productos.filter(p => 
    estado.configuracion?.configuracion.productosDestacados.includes(p.id)
  ).slice(0, 4);

  const productosEnOferta = estado.productos.filter(p => p.enOferta).slice(0, 4);

  const manejarVerProducto = (id: number) => {
    setProductoSeleccionado(id);
    setPaginaActual('producto');
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-50 via-white to-secondary-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Moda Casual
                <span className="block text-primary-600">Para Tu Estilo</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg">
                Descubre nuestra colección de ropa casual para hombre y mujer. 
                Comodidad y estilo en cada prenda.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <button
                  onClick={() => setPaginaActual('catalogo')}
                  className="bg-primary-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-primary-700 transition-colors flex items-center justify-center"
                >
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Explorar Catálogo
                </button>
                <button
                  onClick={() => setPaginaActual('ofertas')}
                  className="bg-secondary-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-secondary-700 transition-colors flex items-center justify-center"
                >
                  Ver Ofertas
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-r from-primary-200 to-secondary-200 rounded-3xl p-8 text-center">
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">¡Nueva Colección!</h3>
                  <p className="text-gray-600 mb-4">Tendencias de temporada con hasta 30% de descuento</p>
                  <div className="flex justify-center items-center space-x-2">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-500 ml-2">4.9/5 (500+ reseñas)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Características de la tienda */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Envío Gratis</h3>
              <p className="text-gray-600">En compras superiores a {estado.configuracion?.configuracion.simboloMoneda}{estado.configuracion?.configuracion.envioGratis}</p>
            </div>
            
            <div className="text-center">
              <div className="bg-secondary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-secondary-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Compra Segura</h3>
              <p className="text-gray-600">Protección total en tus transacciones</p>
            </div>
            
            <div className="text-center">
              <div className="bg-accent-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="h-8 w-8 text-accent-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Devoluciones</h3>
              <p className="text-gray-600">30 días para devoluciones gratuitas</p>
            </div>
            
            <div className="text-center">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Calidad Premium</h3>
              <p className="text-gray-600">Materiales de la mejor calidad</p>
            </div>
          </div>
        </div>
      </section>

      {/* Productos Destacados */}
      {productosDestacados.length > 0 && (
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Productos Destacados</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Descubre nuestros productos más populares y mejor valorados por nuestros clientes
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {productosDestacados.map((producto) => (
                <TarjetaProducto
                  key={producto.id}
                  producto={producto}
                  onVerProducto={manejarVerProducto}
                />
              ))}
            </div>
            
            <div className="text-center mt-12">
              <button
                onClick={() => setPaginaActual('catalogo')}
                className="bg-primary-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors"
              >
                Ver Todos los Productos
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Ofertas Especiales */}
      {productosEnOferta.length > 0 && (
        <section className="py-16 bg-gradient-to-r from-secondary-50 to-primary-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Ofertas Especiales</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                No te pierdas nuestras ofertas limitadas con descuentos increíbles
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {productosEnOferta.map((producto) => (
                <TarjetaProducto
                  key={producto.id}
                  producto={producto}
                  onVerProducto={manejarVerProducto}
                />
              ))}
            </div>
            
            <div className="text-center mt-12">
              <button
                onClick={() => setPaginaActual('ofertas')}
                className="bg-secondary-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-secondary-700 transition-colors"
              >
                Ver Todas las Ofertas
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Categorías */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Compra por Categoría</h2>
            <p className="text-lg text-gray-600">Encuentra exactamente lo que buscas</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div
              onClick={() => {
                dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { categoria: 'hombre' } });
                setPaginaActual('catalogo');
              }}
              className="relative bg-gradient-to-br from-primary-100 to-primary-200 rounded-2xl p-8 cursor-pointer hover:shadow-lg transition-shadow group"
            >
              <div className="text-center">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Ropa para Hombre</h3>
                <p className="text-gray-700 mb-6">Camisetas, polos, pantalones y más</p>
                <div className="bg-white rounded-lg p-4 inline-block group-hover:scale-105 transition-transform">
                  <ShoppingBag className="h-12 w-12 text-primary-600" />
                </div>
              </div>
            </div>
            
            <div
              onClick={() => {
                dispatch({ type: 'ACTUALIZAR_FILTROS', payload: { categoria: 'mujer' } });
                setPaginaActual('catalogo');
              }}
              className="relative bg-gradient-to-br from-secondary-100 to-secondary-200 rounded-2xl p-8 cursor-pointer hover:shadow-lg transition-shadow group"
            >
              <div className="text-center">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Ropa para Mujer</h3>
                <p className="text-gray-700 mb-6">Blusas, vestidos, faldas y más</p>
                <div className="bg-white rounded-lg p-4 inline-block group-hover:scale-105 transition-transform">
                  <ShoppingBag className="h-12 w-12 text-secondary-600" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Mantente al día</h2>
          <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
            Suscríbete a nuestro newsletter y recibe ofertas exclusivas y las últimas tendencias
          </p>
          
          <div className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Tu email"
              className="flex-1 px-4 py-3 rounded-lg border border-gray-600 bg-gray-800 text-white placeholder-gray-400 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
            <button className="bg-primary-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors">
              Suscribirse
            </button>
          </div>
          
          <p className="text-sm text-gray-400 mt-4">
            No spam, solo ofertas increíbles. Puedes darte de baja en cualquier momento.
          </p>
        </div>
      </section>
    </div>
  );
};
