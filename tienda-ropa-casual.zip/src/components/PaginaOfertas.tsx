import React, { useMemo } from 'react';
import { Tag, Clock, Percent, TrendingDown, Filter } from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';
import { TarjetaProducto } from './TarjetaProducto';

interface PaginaOfertasProps {
  setProductoSeleccionado: (id: number) => void;
  setPaginaActual: (pagina: string) => void;
}

export const PaginaOfertas: React.FC<PaginaOfertasProps> = ({ setProductoSeleccionado, setPaginaActual }) => {
  const { estado } = useTienda();

  const productosEnOferta = useMemo(() => {
    return estado.productos.filter(p => p.enOferta).sort((a, b) => b.descuento - a.descuento);
  }, [estado.productos]);

  const mejoresOfertas = useMemo(() => {
    return productosEnOferta.filter(p => p.descuento >= 20).slice(0, 6);
  }, [productosEnOferta]);

  const ofertas10_20 = useMemo(() => {
    return productosEnOferta.filter(p => p.descuento >= 10 && p.descuento < 20);
  }, [productosEnOferta]);

  const ofertas30Plus = useMemo(() => {
    return productosEnOferta.filter(p => p.descuento >= 30);
  }, [productosEnOferta]);

  const ahorroTotal = useMemo(() => {
    return productosEnOferta.reduce((total, producto) => {
      const ahorro = producto.precio * (producto.descuento / 100);
      return total + ahorro;
    }, 0);
  }, [productosEnOferta]);

  const manejarVerProducto = (id: number) => {
    setProductoSeleccionado(id);
    setPaginaActual('producto');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-secondary-400 to-primary-400 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="bg-white bg-opacity-20 p-4 rounded-full">
              <Tag className="h-12 w-12" />
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Ofertas Especiales
          </h1>
          <p className="text-xl md:text-2xl mb-6 opacity-90">
            Descuentos increíbles en toda nuestra colección
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto mt-8">
            <div className="bg-white bg-opacity-10 rounded-lg p-4">
              <Percent className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">{productosEnOferta.length}</div>
              <div className="text-sm opacity-90">Productos en oferta</div>
            </div>
            
            <div className="bg-white bg-opacity-10 rounded-lg p-4">
              <TrendingDown className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">Hasta 30%</div>
              <div className="text-sm opacity-90">De descuento</div>
            </div>
            
            <div className="bg-white bg-opacity-10 rounded-lg p-4">
              <Clock className="h-8 w-8 mx-auto mb-2" />
              <div className="text-2xl font-bold">€{ahorroTotal.toFixed(0)}</div>
              <div className="text-sm opacity-90">Ahorro total disponible</div>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Ofertas destacadas */}
        {mejoresOfertas.length > 0 && (
          <section className="mb-16">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">🔥 Mejores Ofertas</h2>
              <p className="text-lg text-gray-600">Los descuentos más grandes te esperan aquí</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {mejoresOfertas.map((producto) => (
                <div key={producto.id} className="relative">
                  <div className="absolute -top-2 -right-2 z-10">
                    <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg">
                      ¡TOP OFERTA!
                    </div>
                  </div>
                  <TarjetaProducto
                    producto={producto}
                    onVerProducto={manejarVerProducto}
                  />
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Ofertas por categoría de descuento */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Ofertas 30%+ */}
          {ofertas30Plus.length > 0 && (
            <section>
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  🎉 Descuentos del 30% o más
                </h2>
                <p className="text-gray-600">Los mejores precios del año</p>
              </div>
              
              <div className="space-y-6">
                {ofertas30Plus.slice(0, 4).map((producto) => (
                  <div key={producto.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="flex">
                      <div className="w-24 h-24 bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center flex-shrink-0">
                        <Tag className="h-8 w-8 text-primary-600" />
                      </div>
                      
                      <div className="flex-1 p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold text-gray-900">{producto.nombre}</h3>
                          <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">
                            -{producto.descuento}%
                          </span>
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {producto.descripcion}
                        </p>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg font-bold text-secondary-600">
                              €{(producto.precio * (1 - producto.descuento / 100)).toFixed(2)}
                            </span>
                            <span className="text-sm text-gray-500 line-through">
                              €{producto.precio.toFixed(2)}
                            </span>
                          </div>
                          
                          <button
                            onClick={() => manejarVerProducto(producto.id)}
                            className="bg-primary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-primary-700 transition-colors"
                          >
                            Ver Oferta
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Ofertas 10-20% */}
          {ofertas10_20.length > 0 && (
            <section>
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  💝 Descuentos del 10-20%
                </h2>
                <p className="text-gray-600">Excelentes oportunidades de ahorro</p>
              </div>
              
              <div className="space-y-6">
                {ofertas10_20.slice(0, 4).map((producto) => (
                  <div key={producto.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="flex">
                      <div className="w-24 h-24 bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center flex-shrink-0">
                        <Percent className="h-8 w-8 text-primary-600" />
                      </div>
                      
                      <div className="flex-1 p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold text-gray-900">{producto.nombre}</h3>
                          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-bold">
                            -{producto.descuento}%
                          </span>
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {producto.descripcion}
                        </p>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg font-bold text-primary-600">
                              €{(producto.precio * (1 - producto.descuento / 100)).toFixed(2)}
                            </span>
                            <span className="text-sm text-gray-500 line-through">
                              €{producto.precio.toFixed(2)}
                            </span>
                          </div>
                          
                          <button
                            onClick={() => manejarVerProducto(producto.id)}
                            className="bg-secondary-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-secondary-700 transition-colors"
                          >
                            Ver Oferta
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Todos los productos en oferta */}
        {productosEnOferta.length > 0 && (
          <section className="mt-16">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Todas las Ofertas</h2>
              <p className="text-lg text-gray-600">
                Explora todos nuestros productos con descuento
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {productosEnOferta.map((producto) => (
                <TarjetaProducto
                  key={producto.id}
                  producto={producto}
                  onVerProducto={manejarVerProducto}
                />
              ))}
            </div>
          </section>
        )}

        {/* Sin ofertas disponibles */}
        {productosEnOferta.length === 0 && (
          <div className="text-center py-16">
            <div className="text-gray-400 mb-6">
              <Tag className="h-20 w-20 mx-auto" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              No hay ofertas disponibles
            </h2>
            <p className="text-gray-600 mb-8">
              Actualmente no tenemos productos en oferta, pero no te preocupes, 
              ¡pronto tendremos descuentos increíbles!
            </p>
            <button
              onClick={() => setPaginaActual('catalogo')}
              className="bg-primary-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-primary-700 transition-colors"
            >
              Ver Catálogo Completo
            </button>
          </div>
        )}

        {/* Suscripción a ofertas */}
        <section className="mt-16 bg-gradient-to-r from-primary-600 to-secondary-600 rounded-2xl p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">¡No te pierdas ninguna oferta!</h2>
          <p className="text-lg mb-6 opacity-90">
            Suscríbete a nuestras notificaciones y sé el primero en conocer nuestras ofertas exclusivas
          </p>
          
          <div className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Tu email"
              className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:ring-2 focus:ring-white focus:outline-none"
            />
            <button className="bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Suscribirse
            </button>
          </div>
          
          <p className="text-sm mt-4 opacity-75">
            Te enviaremos máximo 2 emails por semana. Puedes darte de baja en cualquier momento.
          </p>
        </section>

        {/* Términos de ofertas */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>
            * Los descuentos son aplicados automáticamente. Ofertas válidas hasta agotar stock. 
            No acumulables con otras promociones.
          </p>
        </div>
      </div>
    </div>
  );
};
