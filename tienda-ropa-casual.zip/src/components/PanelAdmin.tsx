import React, { useState } from 'react';
import { 
  BarChart3, Package, Users, ShoppingCart, Settings, Plus, Edit, Trash2, 
  Eye, TrendingUp, DollarSign, AlertTriangle, CheckCircle, Clock, Truck 
} from 'lucide-react';
import { useTienda } from '../contexts/TiendaContext';

interface PanelAdminProps {
  setPaginaActual: (pagina: string) => void;
}

export const PanelAdmin: React.FC<PanelAdminProps> = ({ setPaginaActual }) => {
  const { estado, dispatch } = useTienda();
  const [seccionActiva, setSeccionActiva] = useState('dashboard');
  const [productoEdicion, setProductoEdicion] = useState<any>(null);
  const [mostrarFormularioProducto, setMostrarFormularioProducto] = useState(false);

  // Verificar si el usuario es admin
  if (!estado.usuario?.esAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Acceso Denegado</h2>
          <p className="text-gray-600 mb-8">No tienes permisos para acceder al panel administrativo.</p>
          <button
            onClick={() => setPaginaActual('inicio')}
            className="bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition-colors"
          >
            Volver al Inicio
          </button>
        </div>
      </div>
    );
  }

  // Estadísticas del dashboard
  const totalProductos = estado.productos.length;
  const totalPedidos = estado.pedidos.length;
  const productosStockBajo = estado.productos.filter(p => p.stock < 10).length;
  const ventasTotal = estado.pedidos.reduce((total, pedido) => total + pedido.total, 0);
  const pedidosPendientes = estado.pedidos.filter(p => p.estado === 'pendiente').length;

  const Sidebar = () => (
    <div className="w-64 bg-white shadow-lg h-screen sticky top-0">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-900">Panel Admin</h2>
        <p className="text-sm text-gray-600">Gestión de la tienda</p>
      </div>
      
      <nav className="mt-6">
        <div className="px-3">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
            { id: 'productos', label: 'Productos', icon: Package },
            { id: 'pedidos', label: 'Pedidos', icon: ShoppingCart },
            { id: 'usuarios', label: 'Usuarios', icon: Users },
            { id: 'configuracion', label: 'Configuración', icon: Settings },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setSeccionActiva(item.id)}
                className={`w-full flex items-center px-3 py-3 rounded-lg mb-2 transition-colors ${
                  seccionActiva === item.id
                    ? 'bg-primary-50 text-primary-700 border-r-2 border-primary-600'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Icon className="h-5 w-5 mr-3" />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>

      <div className="absolute bottom-0 w-full p-4 border-t border-gray-200">
        <button
          onClick={() => setPaginaActual('inicio')}
          className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors"
        >
          ← Volver a la tienda
        </button>
      </div>
    </div>
  );

  const Dashboard = () => (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
      
      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Ventas Total</p>
              <p className="text-2xl font-bold text-gray-900">€{ventasTotal.toFixed(2)}</p>
            </div>
            <DollarSign className="h-8 w-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Pedidos</p>
              <p className="text-2xl font-bold text-gray-900">{totalPedidos}</p>
            </div>
            <ShoppingCart className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Productos</p>
              <p className="text-2xl font-bold text-gray-900">{totalProductos}</p>
            </div>
            <Package className="h-8 w-8 text-purple-600" />
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Stock Bajo</p>
              <p className="text-2xl font-bold text-gray-900">{productosStockBajo}</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-red-600" />
          </div>
        </div>
      </div>

      {/* Pedidos recientes */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Pedidos Recientes</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Pedido</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Cliente</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Total</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Estado</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Fecha</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {estado.pedidos.slice(0, 5).map((pedido) => (
                <tr key={pedido.id} className="hover:bg-gray-50">
                  <td className="p-4 text-sm font-medium text-gray-900">{pedido.id}</td>
                  <td className="p-4 text-sm text-gray-600">{pedido.direccionEnvio.nombre}</td>
                  <td className="p-4 text-sm text-gray-900">€{pedido.total.toFixed(2)}</td>
                  <td className="p-4">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      pedido.estado === 'entregado' ? 'bg-green-100 text-green-800' :
                      pedido.estado === 'en_proceso' ? 'bg-yellow-100 text-yellow-800' :
                      pedido.estado === 'enviado' ? 'bg-blue-100 text-blue-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {pedido.estado.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-gray-600">{pedido.fecha}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Productos con stock bajo */}
      {productosStockBajo > 0 && (
        <div className="bg-white rounded-lg shadow-md">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Productos con Stock Bajo</h2>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              {estado.productos.filter(p => p.stock < 10).map((producto) => (
                <div key={producto.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div>
                    <h3 className="font-medium text-gray-900">{producto.nombre}</h3>
                    <p className="text-sm text-gray-600">Stock: {producto.stock} unidades</p>
                  </div>
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const GestionProductos = () => {
    const [nuevoProducto, setNuevoProducto] = useState({
      nombre: '',
      descripcion: '',
      precio: 0,
      categoria: '',
      subcategoria: '',
      tallas: [],
      colores: [],
      stock: 0,
      enOferta: false,
      descuento: 0,
    });

    const manejarAgregarProducto = () => {
      const id = Math.max(...estado.productos.map(p => p.id)) + 1;
      const producto = {
        ...nuevoProducto,
        id,
        imagen: '/images/placeholder-producto.svg',
        imagenes: ['/images/placeholder-producto.svg'],
        rating: 4.5,
        reviews: 0,
      };
      
      dispatch({ type: 'AGREGAR_PRODUCTO', payload: producto });
      setMostrarFormularioProducto(false);
      setNuevoProducto({
        nombre: '',
        descripcion: '',
        precio: 0,
        categoria: '',
        subcategoria: '',
        tallas: [],
        colores: [],
        stock: 0,
        enOferta: false,
        descuento: 0,
      });
    };

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Gestión de Productos</h1>
          <button
            onClick={() => setMostrarFormularioProducto(true)}
            className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Agregar Producto
          </button>
        </div>

        {/* Modal agregar producto */}
        {mostrarFormularioProducto && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Agregar Nuevo Producto</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                  <input
                    type="text"
                    value={nuevoProducto.nombre}
                    onChange={(e) => setNuevoProducto({...nuevoProducto, nombre: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Precio</label>
                  <input
                    type="number"
                    step="0.01"
                    value={nuevoProducto.precio}
                    onChange={(e) => setNuevoProducto({...nuevoProducto, precio: parseFloat(e.target.value)})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Categoría</label>
                  <select
                    value={nuevoProducto.categoria}
                    onChange={(e) => setNuevoProducto({...nuevoProducto, categoria: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  >
                    <option value="">Seleccionar</option>
                    <option value="hombre">Hombre</option>
                    <option value="mujer">Mujer</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Stock</label>
                  <input
                    type="number"
                    value={nuevoProducto.stock}
                    onChange={(e) => setNuevoProducto({...nuevoProducto, stock: parseInt(e.target.value)})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>
              
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
                <textarea
                  value={nuevoProducto.descripcion}
                  onChange={(e) => setNuevoProducto({...nuevoProducto, descripcion: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  rows={3}
                />
              </div>

              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setMostrarFormularioProducto(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={manejarAgregarProducto}
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
                >
                  Agregar Producto
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Lista de productos */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 text-sm font-medium text-gray-700">Producto</th>
                  <th className="text-left p-4 text-sm font-medium text-gray-700">Categoría</th>
                  <th className="text-left p-4 text-sm font-medium text-gray-700">Precio</th>
                  <th className="text-left p-4 text-sm font-medium text-gray-700">Stock</th>
                  <th className="text-left p-4 text-sm font-medium text-gray-700">Estado</th>
                  <th className="text-left p-4 text-sm font-medium text-gray-700">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {estado.productos.map((producto) => (
                  <tr key={producto.id} className="hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg mr-3"></div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{producto.nombre}</div>
                          <div className="text-xs text-gray-500">{producto.descripcion.substring(0, 50)}...</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-sm text-gray-600 capitalize">{producto.categoria}</td>
                    <td className="p-4 text-sm text-gray-900">€{producto.precio.toFixed(2)}</td>
                    <td className="p-4">
                      <span className={`text-sm ${
                        producto.stock < 10 ? 'text-red-600 font-medium' : 'text-gray-600'
                      }`}>
                        {producto.stock}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        producto.stock > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {producto.stock > 0 ? 'En stock' : 'Agotado'}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <button className="text-blue-600 hover:text-blue-700">
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="text-green-600 hover:text-green-700">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => dispatch({ type: 'ELIMINAR_PRODUCTO', payload: producto.id })}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const GestionPedidos = () => (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Gestión de Pedidos</h1>
      
      <div className="bg-white rounded-lg shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Pedido</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Cliente</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Productos</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Total</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Estado</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Fecha</th>
                <th className="text-left p-4 text-sm font-medium text-gray-700">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {estado.pedidos.map((pedido) => (
                <tr key={pedido.id} className="hover:bg-gray-50">
                  <td className="p-4 text-sm font-medium text-gray-900">{pedido.id}</td>
                  <td className="p-4 text-sm text-gray-600">{pedido.direccionEnvio.nombre}</td>
                  <td className="p-4 text-sm text-gray-600">{pedido.productos.length} productos</td>
                  <td className="p-4 text-sm text-gray-900">€{pedido.total.toFixed(2)}</td>
                  <td className="p-4">
                    <select
                      value={pedido.estado}
                      onChange={(e) => dispatch({ 
                        type: 'ACTUALIZAR_ESTADO_PEDIDO', 
                        payload: { id: pedido.id, estado: e.target.value } 
                      })}
                      className="text-xs border border-gray-300 rounded px-2 py-1"
                    >
                      <option value="pendiente">Pendiente</option>
                      <option value="en_proceso">En Proceso</option>
                      <option value="enviado">Enviado</option>
                      <option value="entregado">Entregado</option>
                      <option value="cancelado">Cancelado</option>
                    </select>
                  </td>
                  <td className="p-4 text-sm text-gray-600">{pedido.fecha}</td>
                  <td className="p-4">
                    <button className="text-blue-600 hover:text-blue-700">
                      <Eye className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (seccionActiva) {
      case 'dashboard':
        return <Dashboard />;
      case 'productos':
        return <GestionProductos />;
      case 'pedidos':
        return <GestionPedidos />;
      case 'usuarios':
        return (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Gestión de Usuarios</h1>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-600">Funcionalidad de gestión de usuarios en desarrollo.</p>
            </div>
          </div>
        );
      case 'configuracion':
        return (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Configuración</h1>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-600">Panel de configuración en desarrollo.</p>
            </div>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <Sidebar />
      <div className="flex-1 p-8">
        {renderContent()}
      </div>
    </div>
  );
};
