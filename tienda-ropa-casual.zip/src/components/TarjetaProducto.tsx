import React from 'react';
import { Star, ShoppingCart, Heart, Tag } from 'lucide-react';
import { Producto } from '../contexts/TiendaContext';

interface TarjetaProductoProps {
  producto: Producto;
  onVerProducto: (id: number) => void;
}

export const TarjetaProducto: React.FC<TarjetaProductoProps> = ({ producto, onVerProducto }) => {
  const precioFinal = producto.enOferta 
    ? producto.precio * (1 - producto.descuento / 100)
    : producto.precio;

  const esStockBajo = producto.stock < 10;

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow group cursor-pointer">
      {/* Imagen del producto */}
      <div className="relative overflow-hidden rounded-t-lg">
        <div 
          className="h-64 bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center"
          onClick={() => onVerProducto(producto.id)}
        >
          <div className="text-center p-4">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-2">
              <ShoppingCart className="h-8 w-8 text-primary-600" />
            </div>
            <span className="text-sm text-gray-600">{producto.categoria}</span>
          </div>
        </div>
        
        {/* Badges */}
        <div className="absolute top-2 left-2 space-y-1">
          {producto.enOferta && (
            <span className="bg-secondary-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center">
              <Tag className="h-3 w-3 mr-1" />
              -{producto.descuento}%
            </span>
          )}
          {esStockBajo && (
            <span className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
              ¡Últimas unidades!
            </span>
          )}
        </div>

        {/* Botón de favoritos */}
        <button className="absolute top-2 right-2 bg-white p-2 rounded-full shadow-md hover:bg-gray-50 transition-colors opacity-0 group-hover:opacity-100">
          <Heart className="h-4 w-4 text-gray-600 hover:text-red-500" />
        </button>

        {/* Overlay con botón de ver producto */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
          <button
            onClick={() => onVerProducto(producto.id)}
            className="bg-white text-gray-900 px-4 py-2 rounded-lg font-semibold transform translate-y-4 group-hover:translate-y-0 transition-transform"
          >
            Ver Producto
          </button>
        </div>
      </div>

      {/* Información del producto */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 
            className="text-lg font-semibold text-gray-900 line-clamp-2 cursor-pointer hover:text-primary-600"
            onClick={() => onVerProducto(producto.id)}
          >
            {producto.nombre}
          </h3>
        </div>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {producto.descripcion}
        </p>

        {/* Rating */}
        <div className="flex items-center mb-3">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < Math.floor(producto.rating)
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-500 ml-2">
            {producto.rating} ({producto.reviews})
          </span>
        </div>

        {/* Colores disponibles */}
        <div className="mb-3">
          <div className="flex items-center space-x-1">
            <span className="text-xs text-gray-500">Colores:</span>
            <div className="flex space-x-1">
              {producto.colores.slice(0, 3).map((color, index) => (
                <div
                  key={index}
                  className="w-4 h-4 rounded-full border border-gray-300 bg-gradient-to-r from-primary-200 to-secondary-200"
                  title={color}
                />
              ))}
              {producto.colores.length > 3 && (
                <span className="text-xs text-gray-400">+{producto.colores.length - 3}</span>
              )}
            </div>
          </div>
        </div>

        {/* Tallas disponibles */}
        <div className="mb-4">
          <div className="flex items-center flex-wrap gap-1">
            <span className="text-xs text-gray-500">Tallas:</span>
            {producto.tallas.slice(0, 4).map((talla) => (
              <span
                key={talla}
                className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
              >
                {talla}
              </span>
            ))}
            {producto.tallas.length > 4 && (
              <span className="text-xs text-gray-400">+{producto.tallas.length - 4}</span>
            )}
          </div>
        </div>

        {/* Precio y botón de compra */}
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            {producto.enOferta ? (
              <>
                <span className="text-lg font-bold text-secondary-600">
                  €{precioFinal.toFixed(2)}
                </span>
                <span className="text-sm text-gray-500 line-through">
                  €{producto.precio.toFixed(2)}
                </span>
              </>
            ) : (
              <span className="text-lg font-bold text-gray-900">
                €{producto.precio.toFixed(2)}
              </span>
            )}
          </div>

          <button
            onClick={() => onVerProducto(producto.id)}
            className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors flex items-center"
            disabled={producto.stock === 0}
          >
            {producto.stock === 0 ? (
              'Agotado'
            ) : (
              <>
                <ShoppingCart className="h-4 w-4 mr-1" />
                Comprar
              </>
            )}
          </button>
        </div>

        {/* Stock disponible */}
        <div className="mt-2">
          {producto.stock === 0 ? (
            <span className="text-red-500 text-xs">Sin stock</span>
          ) : esStockBajo ? (
            <span className="text-orange-500 text-xs">
              Solo {producto.stock} unidades disponibles
            </span>
          ) : (
            <span className="text-green-500 text-xs">
              En stock ({producto.stock} disponibles)
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
