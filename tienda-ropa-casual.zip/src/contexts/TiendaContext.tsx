import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';

// Tipos de datos
export interface Producto {
  id: number;
  nombre: string;
  descripcion: string;
  precio: number;
  categoria: string;
  subcategoria: string;
  tallas: string[];
  colores: string[];
  stock: number;
  imagen: string;
  imagenes: string[];
  enOferta: boolean;
  descuento: number;
  rating: number;
  reviews: number;
}

export interface ProductoCarrito extends Producto {
  cantidad: number;
  tallaSeleccionada: string;
  colorSeleccionado: string;
}

export interface Usuario {
  id: number;
  nombre: string;
  email: string;
  telefono: string;
  direccion: {
    calle: string;
    ciudad: string;
    codigoPostal: string;
    pais: string;
  };
  fechaRegistro: string;
  esAdmin: boolean;
}

export interface Pedido {
  id: string;
  usuarioId: number;
  fecha: string;
  estado: 'pendiente' | 'en_proceso' | 'enviado' | 'entregado' | 'cancelado';
  productos: Array<{
    id: number;
    nombre: string;
    precio: number;
    cantidad: number;
    talla: string;
    color: string;
  }>;
  subtotal: number;
  envio: number;
  total: number;
  direccionEnvio: {
    nombre: string;
    calle: string;
    ciudad: string;
    codigoPostal: string;
    pais: string;
  };
  metodoPago: string;
  estadosPago: string;
}

export interface Configuracion {
  tienda: {
    nombre: string;
    descripcion: string;
    logo: string;
    colores: {
      primario: string;
      secundario: string;
      acento: string;
    };
    contacto: {
      email: string;
      telefono: string;
      direccion: string;
    };
    redes: {
      instagram: string;
      facebook: string;
      twitter: string;
    };
  };
  configuracion: {
    envioGratis: number;
    costoEnvio: number;
    iva: number;
    moneda: string;
    simboloMoneda: string;
    idioma: string;
    stockMinimo: number;
    productosDestacados: number[];
    categorias: Array<{
      id: string;
      nombre: string;
      subcategorias: string[];
    }>;
    tallas: {
      hombre: string[];
      mujer: string[];
      pantalones: string[];
    };
    metodosPago: Array<{
      id: string;
      nombre: string;
      icono: string;
      activo: boolean;
    }>;
  };
}

// Estado de la aplicación
interface EstadoTienda {
  productos: Producto[];
  carrito: ProductoCarrito[];
  usuario: Usuario | null;
  pedidos: Pedido[];
  configuracion: Configuracion | null;
  filtros: {
    categoria: string;
    subcategoria: string;
    precioMin: number;
    precioMax: number;
    talla: string;
    color: string;
    busqueda: string;
  };
  cargando: boolean;
  error: string | null;
}

// Acciones del reducer
type AccionTienda =
  | { type: 'CARGAR_PRODUCTOS'; payload: Producto[] }
  | { type: 'CARGAR_CONFIGURACION'; payload: Configuracion }
  | { type: 'CARGAR_PEDIDOS'; payload: Pedido[] }
  | { type: 'AGREGAR_AL_CARRITO'; payload: ProductoCarrito }
  | { type: 'ELIMINAR_DEL_CARRITO'; payload: number }
  | { type: 'ACTUALIZAR_CANTIDAD_CARRITO'; payload: { id: number; cantidad: number } }
  | { type: 'LIMPIAR_CARRITO' }
  | { type: 'INICIAR_SESION'; payload: Usuario }
  | { type: 'CERRAR_SESION' }
  | { type: 'ACTUALIZAR_FILTROS'; payload: Partial<EstadoTienda['filtros']> }
  | { type: 'ESTABLECER_CARGANDO'; payload: boolean }
  | { type: 'ESTABLECER_ERROR'; payload: string | null }
  | { type: 'AGREGAR_PRODUCTO'; payload: Producto }
  | { type: 'ACTUALIZAR_PRODUCTO'; payload: Producto }
  | { type: 'ELIMINAR_PRODUCTO'; payload: number }
  | { type: 'AGREGAR_PEDIDO'; payload: Pedido }
  | { type: 'ACTUALIZAR_ESTADO_PEDIDO'; payload: { id: string; estado: string } };

// Estado inicial
const estadoInicial: EstadoTienda = {
  productos: [],
  carrito: [],
  usuario: null,
  pedidos: [],
  configuracion: null,
  filtros: {
    categoria: '',
    subcategoria: '',
    precioMin: 0,
    precioMax: 1000,
    talla: '',
    color: '',
    busqueda: '',
  },
  cargando: false,
  error: null,
};

// Reducer
const tiendaReducer = (estado: EstadoTienda, accion: AccionTienda): EstadoTienda => {
  switch (accion.type) {
    case 'CARGAR_PRODUCTOS':
      return { ...estado, productos: accion.payload, cargando: false };
    
    case 'CARGAR_CONFIGURACION':
      return { ...estado, configuracion: accion.payload };
    
    case 'CARGAR_PEDIDOS':
      return { ...estado, pedidos: accion.payload };
    
    case 'AGREGAR_AL_CARRITO':
      const productoExistente = estado.carrito.find(
        item => item.id === accion.payload.id && 
                item.tallaSeleccionada === accion.payload.tallaSeleccionada &&
                item.colorSeleccionado === accion.payload.colorSeleccionado
      );
      
      if (productoExistente) {
        return {
          ...estado,
          carrito: estado.carrito.map(item =>
            item.id === accion.payload.id && 
            item.tallaSeleccionada === accion.payload.tallaSeleccionada &&
            item.colorSeleccionado === accion.payload.colorSeleccionado
              ? { ...item, cantidad: item.cantidad + accion.payload.cantidad }
              : item
          ),
        };
      }
      
      return { ...estado, carrito: [...estado.carrito, accion.payload] };
    
    case 'ELIMINAR_DEL_CARRITO':
      return {
        ...estado,
        carrito: estado.carrito.filter((_, index) => index !== accion.payload),
      };
    
    case 'ACTUALIZAR_CANTIDAD_CARRITO':
      return {
        ...estado,
        carrito: estado.carrito.map((item, index) =>
          index === accion.payload.id
            ? { ...item, cantidad: accion.payload.cantidad }
            : item
        ),
      };
    
    case 'LIMPIAR_CARRITO':
      return { ...estado, carrito: [] };
    
    case 'INICIAR_SESION':
      return { ...estado, usuario: accion.payload };
    
    case 'CERRAR_SESION':
      return { ...estado, usuario: null };
    
    case 'ACTUALIZAR_FILTROS':
      return { ...estado, filtros: { ...estado.filtros, ...accion.payload } };
    
    case 'ESTABLECER_CARGANDO':
      return { ...estado, cargando: accion.payload };
    
    case 'ESTABLECER_ERROR':
      return { ...estado, error: accion.payload, cargando: false };
    
    case 'AGREGAR_PRODUCTO':
      return { ...estado, productos: [...estado.productos, accion.payload] };
    
    case 'ACTUALIZAR_PRODUCTO':
      return {
        ...estado,
        productos: estado.productos.map(p =>
          p.id === accion.payload.id ? accion.payload : p
        ),
      };
    
    case 'ELIMINAR_PRODUCTO':
      return {
        ...estado,
        productos: estado.productos.filter(p => p.id !== accion.payload),
      };
    
    case 'AGREGAR_PEDIDO':
      return { ...estado, pedidos: [...estado.pedidos, accion.payload] };
    
    case 'ACTUALIZAR_ESTADO_PEDIDO':
      return {
        ...estado,
        pedidos: estado.pedidos.map(p =>
          p.id === accion.payload.id ? { ...p, estado: accion.payload.estado as any } : p
        ),
      };
    
    default:
      return estado;
  }
};

// Contexto
const TiendaContext = createContext<{
  estado: EstadoTienda;
  dispatch: React.Dispatch<AccionTienda>;
} | null>(null);

// Provider
export const TiendaProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [estado, dispatch] = useReducer(tiendaReducer, estadoInicial);

  // Cargar datos iniciales
  useEffect(() => {
    const cargarDatos = async () => {
      dispatch({ type: 'ESTABLECER_CARGANDO', payload: true });
      
      try {
        // Cargar productos
        const respuestaProductos = await fetch('/productos.json');
        const productos = await respuestaProductos.json();
        dispatch({ type: 'CARGAR_PRODUCTOS', payload: productos });
        
        // Cargar configuración
        const respuestaConfig = await fetch('/configuracion.json');
        const configuracion = await respuestaConfig.json();
        dispatch({ type: 'CARGAR_CONFIGURACION', payload: configuracion });
        
        // Cargar pedidos
        const respuestaPedidos = await fetch('/pedidos.json');
        const pedidos = await respuestaPedidos.json();
        dispatch({ type: 'CARGAR_PEDIDOS', payload: pedidos });
        
        // Restaurar carrito del localStorage
        const carritoGuardado = localStorage.getItem('carrito');
        if (carritoGuardado) {
          const carrito = JSON.parse(carritoGuardado);
          carrito.forEach((producto: ProductoCarrito) => {
            dispatch({ type: 'AGREGAR_AL_CARRITO', payload: producto });
          });
        }
        
        // Restaurar usuario del localStorage
        const usuarioGuardado = localStorage.getItem('usuario');
        if (usuarioGuardado) {
          const usuario = JSON.parse(usuarioGuardado);
          dispatch({ type: 'INICIAR_SESION', payload: usuario });
        }
        
      } catch (error) {
        dispatch({ type: 'ESTABLECER_ERROR', payload: 'Error al cargar los datos' });
        console.error('Error cargando datos:', error);
      }
    };
    
    cargarDatos();
  }, []);

  // Guardar carrito en localStorage
  useEffect(() => {
    localStorage.setItem('carrito', JSON.stringify(estado.carrito));
  }, [estado.carrito]);

  // Guardar usuario en localStorage
  useEffect(() => {
    if (estado.usuario) {
      localStorage.setItem('usuario', JSON.stringify(estado.usuario));
    } else {
      localStorage.removeItem('usuario');
    }
  }, [estado.usuario]);

  return (
    <TiendaContext.Provider value={{ estado, dispatch }}>
      {children}
    </TiendaContext.Provider>
  );
};

// Hook personalizado
export const useTienda = () => {
  const contexto = useContext(TiendaContext);
  if (!contexto) {
    throw new Error('useTienda debe usarse dentro de TiendaProvider');
  }
  return contexto;
};
