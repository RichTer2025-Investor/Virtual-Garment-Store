/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px',
			},
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: '#87CEEB', // Celeste pastel
					foreground: '#FFFFFF',
					50: '#F0F8FE',
					100: '#E0F2FE',
					200: '#B9E6FE',
					300: '#87CEEB',
					400: '#5BB6E8',
					500: '#3A9FDC',
					600: '#2D8BC7',
					700: '#246FA1',
					800: '#1E5A85',
					900: '#1A4A6E',
				},
				secondary: {
					DEFAULT: '#F8BBD0', // Rosado pastel
					foreground: '#8B0000',
					50: '#FEF7F7',
					100: '#FDF2F2',
					200: '#FCE7E7',
					300: '#F8BBD0',
					400: '#F48FB1',
					500: '#EC407A',
					600: '#E91E63',
					700: '#C2185B',
					800: '#AD1457',
					900: '#880E4F',
				},
				accent: {
					DEFAULT: '#DDA0DD', // Lavanda pastel para acentos
					foreground: '#4A4A4A',
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))',
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))',
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))',
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))',
				},
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)',
			},
			keyframes: {
				'accordion-down': {
					from: { height: 0 },
					to: { height: 'var(--radix-accordion-content-height)' },
				},
				'accordion-up': {
					from: { height: 'var(--radix-accordion-content-height)' },
					to: { height: 0 },
				},
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
}